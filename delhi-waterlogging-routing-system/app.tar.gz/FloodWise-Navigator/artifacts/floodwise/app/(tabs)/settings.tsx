import React, { useEffect, useState } from 'react';
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as Notifications from 'expo-notifications';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppCard, ActionButton, ScreenTitle } from '@/src/components/ui';
import { useAppColors } from '@/src/hooks/useAppColors';
import { useFloodStore } from '@/src/store/appStore';
import type { AppSettings } from '@/src/types/domain';
import { getGoogleMapsKey, saveGoogleMapsKey, savePredictionApiKey } from '@/src/services/maps';

function ChoiceRow<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string; icon?: React.ComponentProps<typeof Feather>['name'] }[];
  onChange: (value: T) => void;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.choiceSection}>
      <Text style={[styles.settingLabel, { color: colors.foreground }]}>{label}</Text>
      <View style={[styles.choiceRow, { backgroundColor: colors.secondary }]}>
        {options.map((option) => {
          const active = value === option.value;
          return (
            <Pressable
              key={option.value}
              accessibilityRole="radio"
              accessibilityState={{ selected: active }}
              onPress={() => onChange(option.value)}
              style={[
                styles.choice,
                { backgroundColor: active ? colors.card : 'transparent' },
              ]}
            >
              {option.icon ? (
                <Feather name={option.icon} size={13} color={active ? colors.primary : colors.mutedForeground} />
              ) : null}
              <Text style={[styles.choiceText, { color: active ? colors.foreground : colors.mutedForeground }]}>
                {option.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

function ToggleRow({
  title,
  description,
  value,
  onValueChange,
}: {
  title: string;
  description: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.toggleRow}>
      <View style={{ flex: 1, paddingRight: 10 }}>
        <Text style={[styles.settingLabel, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.settingDescription, { color: colors.mutedForeground }]}>{description}</Text>
      </View>
      <Switch
        accessibilityLabel={title}
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: colors.border, true: colors.primary }}
        thumbColor="#ffffff"
      />
    </View>
  );
}

function SettingsSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>{title}</Text>
      <AppCard style={styles.sectionCard}>{children}</AppCard>
    </View>
  );
}

export default function SettingsScreen() {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  const settings = useFloodStore((state) => state.settings);
  const updateSettings = useFloodStore((state) => state.updateSettings);
  const [googleKeyInput, setGoogleKeyInput] = useState('');
  const [predictionKeyInput, setPredictionKeyInput] = useState('');
  const [googleKeySaved, setGoogleKeySaved] = useState(false);
  const [privacyVisible, setPrivacyVisible] = useState(false);
  const [aboutVisible, setAboutVisible] = useState(false);
  const [savingKey, setSavingKey] = useState(false);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    void getGoogleMapsKey()
      .then((key) => setGoogleKeySaved(Boolean(key)))
      .catch(() => setGoogleKeySaved(false));
  }, []);

  function patch<K extends keyof AppSettings>(key: K, value: AppSettings[K]) {
    updateSettings({ [key]: value } as Pick<AppSettings, K>);
  }

  async function setAlerts(enabled: boolean) {
    if (!enabled) {
      patch('alertsEnabled', false);
      return;
    }
    const current = await Notifications.getPermissionsAsync();
    const permission = current.granted ? current : await Notifications.requestPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Notifications are off', 'Allow notifications in device settings to receive local risk alerts.');
      patch('alertsEnabled', false);
      return;
    }
    patch('alertsEnabled', true);
  }

  async function persistGoogleKey() {
    setSavingKey(true);
    try {
      await saveGoogleMapsKey(googleKeyInput);
      setGoogleKeySaved(Boolean(googleKeyInput.trim()));
      setGoogleKeyInput('');
      if (!googleKeyInput.trim()) patch('mapMode', 'free');
      Alert.alert(
        googleKeyInput.trim() ? 'Google key saved securely' : 'Google key removed',
        'The key is stored in this device’s secure storage, not in app preferences.',
      );
    } catch {
      Alert.alert('Could not save key', 'Secure storage is not available on this device.');
    } finally {
      setSavingKey(false);
    }
  }

  async function persistPredictionKey() {
    setSavingKey(true);
    try {
      await savePredictionApiKey(predictionKeyInput);
      setPredictionKeyInput('');
      Alert.alert('Model API key saved', 'Stored in this device’s secure storage.');
    } catch {
      Alert.alert('Could not save key', 'Secure storage is not available on this device.');
    } finally {
      setSavingKey(false);
    }
  }

  const privacyCopy =
    'FloodWise demo stores saved places, route history, settings and community reports locally on this device. Place search, map tiles, routing and optional weather lookups send the coordinates or search text to the selected public provider. Risk values in mock mode are simulated and are not emergency advice. Photos stay in your local report until a backend is added. Secret keys are held in the device secure store.';

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: Math.max(insets.bottom, 14) + 90 }]}>
        <ScreenTitle
          title="Settings"
          subtitle="Tune risk alerts, map services and model connections."
          action={
            <View style={[styles.titleIcon, { backgroundColor: colors.accent }]}>
              <Feather name="sliders" size={20} color={colors.primary} />
            </View>
          }
        />

        <SettingsSection title="PERSONALIZE">
          <ChoiceRow
            label="Appearance"
            value={settings.theme}
            options={[
              { value: 'system', label: 'System', icon: 'smartphone' },
              { value: 'light', label: 'Light', icon: 'sun' },
              { value: 'dark', label: 'Dark', icon: 'moon' },
            ]}
            onChange={(value) => patch('theme', value)}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <ChoiceRow
            label="Distance units"
            value={settings.units}
            options={[
              { value: 'km', label: 'Kilometres' },
              { value: 'mi', label: 'Miles' },
            ]}
            onChange={(value) => patch('units', value)}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <ChoiceRow
            label="Alert me at"
            value={settings.riskThreshold}
            options={[
              { value: 'low', label: 'Low' },
              { value: 'moderate', label: 'Moderate' },
              { value: 'high', label: 'High' },
              { value: 'severe', label: 'Severe' },
            ]}
            onChange={(value) => patch('riskThreshold', value)}
          />
        </SettingsSection>

        <SettingsSection title="ALERTS & WEATHER">
          <ToggleRow
            title="Local risk alerts"
            description="Notify when a saved place crosses your risk threshold during an in-app check."
            value={settings.alertsEnabled}
            onValueChange={(value) => void setAlerts(value)}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <ToggleRow
            title="Quiet hours"
            description="Pause alerts from 10 pm to 7 am."
            value={settings.quietHoursEnabled}
            onValueChange={(value) => patch('quietHoursEnabled', value)}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <ToggleRow
            title="Auto-fetch weather"
            description="Use Open-Meteo rainfall and elevation. Turn off to use demo/manual inputs."
            value={settings.weatherAutoFetch}
            onValueChange={(value) => patch('weatherAutoFetch', value)}
          />
        </SettingsSection>

        <SettingsSection title="PREDICTION SOURCE">
          <ChoiceRow
            label="Model mode"
            value={settings.predictionMode}
            options={[
              { value: 'mock', label: 'Mock' },
              { value: 'remote', label: 'Remote API' },
              { value: 'ondevice', label: 'On-device' },
            ]}
            onChange={(value) => patch('predictionMode', value)}
          />
          {settings.predictionMode === 'mock' ? (
            <Text style={[styles.inlineNotice, { color: colors.mutedForeground }]}>
              The deterministic demo model reacts to rainfall, duration, elevation and the drainage lookup. It is not an official forecast.
            </Text>
          ) : null}
          {settings.predictionMode === 'ondevice' ? (
            <Text style={[styles.inlineNotice, { color: colors.mutedForeground }]}>
              The on-device service is an explicit stub. Add a TFLite or ONNX runtime and model before using this mode.
            </Text>
          ) : null}
          <Text style={[styles.inputLabel, { color: colors.foreground }]}>Prediction API URL</Text>
          <TextInput
            accessibilityLabel="Prediction API URL"
            value={settings.predictionApiUrl}
            onChangeText={(value) => patch('predictionApiUrl', value)}
            placeholder="https://your-service.example.com"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="none"
            keyboardType="url"
            style={[styles.textField, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
          />
          <Text style={[styles.inputLabel, { color: colors.foreground }]}>Prediction API key (optional)</Text>
          <TextInput
            accessibilityLabel="Prediction API key"
            value={predictionKeyInput}
            onChangeText={setPredictionKeyInput}
            placeholder="Enter a key for this device"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="none"
            secureTextEntry
            style={[styles.textField, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
          />
          <ActionButton
            label="Save model key securely"
            icon="lock"
            secondary
            compact
            loading={savingKey}
            onPress={() => void persistPredictionKey()}
            style={{ marginTop: 9 }}
          />
        </SettingsSection>

        <SettingsSection title="MAP PROVIDER">
          <ChoiceRow
            label="Search and directions"
            value={settings.mapMode}
            options={[
              { value: 'free', label: 'Free maps' },
              { value: 'google', label: 'Google' },
            ]}
            onChange={(value) => {
              if (value === 'google' && !googleKeySaved) {
                Alert.alert('Add a Google Maps key first', 'Save a key below. Free OpenStreetMap search and routing stay available without one.');
                patch('mapMode', 'free');
                return;
              }
              patch('mapMode', value);
            }}
          />
          <Text style={[styles.inlineNotice, { color: colors.mutedForeground }]}>
            The base map remains OpenStreetMap tiles. A Google key enables Google place search and directions APIs.
          </Text>
          <Text style={[styles.inputLabel, { color: colors.foreground }]}>Google Maps API key</Text>
          <TextInput
            accessibilityLabel="Google Maps API key"
            value={googleKeyInput}
            onChangeText={setGoogleKeyInput}
            placeholder={googleKeySaved ? 'Key saved securely on this device' : 'Paste a key for testing'}
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="none"
            secureTextEntry
            style={[styles.textField, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
          />
          <View style={styles.keyActions}>
            <ActionButton
              label="Save key"
              icon="lock"
              compact
              loading={savingKey}
              onPress={() => void persistGoogleKey()}
              style={{ flex: 1 }}
            />
            {googleKeySaved ? (
              <ActionButton
                label="Remove"
                icon="trash-2"
                compact
                secondary
                onPress={() => {
                  setGoogleKeyInput('');
                  void saveGoogleMapsKey('').then(() => {
                    setGoogleKeySaved(false);
                    patch('mapMode', 'free');
                  });
                }}
                style={{ flex: 1 }}
              />
            ) : null}
          </View>
          <Text style={[styles.keyStatus, { color: googleKeySaved ? colors.accentForeground : colors.mutedForeground }]}>
            {googleKeySaved ? 'A Google key is stored securely.' : 'No Google key needed for free map mode.'}
          </Text>
        </SettingsSection>

        <SettingsSection title="ABOUT">
          <Pressable accessibilityRole="button" onPress={() => setPrivacyVisible(true)} style={styles.linkRow}>
            <View style={[styles.linkIcon, { backgroundColor: colors.secondary }]}><Feather name="shield" size={15} color={colors.secondaryForeground} /></View>
            <Text style={[styles.linkText, { color: colors.foreground }]}>Privacy & data use</Text>
            <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
          </Pressable>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <Pressable accessibilityRole="button" onPress={() => setAboutVisible(true)} style={styles.linkRow}>
            <View style={[styles.linkIcon, { backgroundColor: colors.secondary }]}><Feather name="info" size={15} color={colors.secondaryForeground} /></View>
            <Text style={[styles.linkText, { color: colors.foreground }]}>About FloodWise</Text>
            <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
          </Pressable>
        </SettingsSection>
        <Text style={[styles.footerText, { color: colors.mutedForeground }]}>FloodWise · demo build 1.0.0</Text>
      </ScrollView>

      <InfoModal
        visible={privacyVisible}
        title="Privacy & data use"
        onClose={() => setPrivacyVisible(false)}
        body={privacyCopy}
      />
      <InfoModal
        visible={aboutVisible}
        title="About FloodWise"
        onClose={() => setAboutVisible(false)}
        body="FloodWise helps people explore waterlogging risk around places and compare routes. Mock risk values are for product demonstration only and must not be treated as an official forecast, emergency warning or guarantee of road safety. Always follow local authority guidance."
      />
    </View>
  );
}

function InfoModal({
  visible,
  title,
  body,
  onClose,
}: {
  visible: boolean;
  title: string;
  body: string;
  onClose: () => void;
}) {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.modalBackdrop}>
        <View style={[styles.infoCard, { backgroundColor: colors.card, marginBottom: Math.max(insets.bottom, 16) }]}>
          <View style={styles.infoHeading}>
            <Text style={[styles.infoTitle, { color: colors.foreground }]}>{title}</Text>
            <Pressable accessibilityRole="button" accessibilityLabel="Close" onPress={onClose} style={styles.closeButton}>
              <Feather name="x" size={18} color={colors.mutedForeground} />
            </Pressable>
          </View>
          <Text style={[styles.infoBody, { color: colors.mutedForeground }]}>{body}</Text>
          <ActionButton label="Close" onPress={onClose} />
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18 },
  titleIcon: { width: 47, height: 47, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  section: { marginBottom: 17 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.25, marginBottom: 8, marginLeft: 3 },
  sectionCard: { paddingVertical: 5, paddingHorizontal: 14 },
  choiceSection: { paddingVertical: 10 },
  settingLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  choiceRow: { flexDirection: 'row', gap: 4, padding: 3, borderRadius: 12, marginTop: 8 },
  choice: { minHeight: 34, flex: 1, borderRadius: 9, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 4, paddingHorizontal: 3 },
  choiceText: { fontFamily: 'Inter_600SemiBold', fontSize: 9 },
  divider: { height: StyleSheet.hairlineWidth },
  toggleRow: { minHeight: 67, paddingVertical: 10, flexDirection: 'row', alignItems: 'center' },
  settingDescription: { fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 14, marginTop: 4 },
  inlineNotice: { fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 14, marginTop: 5, marginBottom: 4 },
  inputLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 10, marginTop: 10, marginBottom: 6 },
  textField: { borderWidth: 1, borderRadius: 13, height: 45, paddingHorizontal: 11, fontFamily: 'Inter_400Regular', fontSize: 11 },
  keyActions: { flexDirection: 'row', gap: 8, marginTop: 9 },
  keyStatus: { fontFamily: 'Inter_500Medium', fontSize: 9, marginTop: 9 },
  linkRow: { minHeight: 49, flexDirection: 'row', alignItems: 'center', gap: 10 },
  linkIcon: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  linkText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  footerText: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 0 },
  modalBackdrop: { flex: 1, backgroundColor: '#001b22aa', justifyContent: 'center', padding: 22 },
  infoCard: { borderRadius: 24, padding: 20 },
  infoHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  infoTitle: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  closeButton: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' },
  infoBody: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 19, marginTop: 11, marginBottom: 18 },
});
