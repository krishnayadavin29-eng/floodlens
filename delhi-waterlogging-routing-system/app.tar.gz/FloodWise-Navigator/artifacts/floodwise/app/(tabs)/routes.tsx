import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Linking,
  Pressable,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as Notifications from 'expo-notifications';
import Svg, { Circle, Polyline } from 'react-native-svg';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DEFAULT_MAP_CENTER, RISK_COLORS } from '@/src/config/constants';
import { AppCard, ActionButton, Eyebrow, IconButton, RiskBadge, ScreenTitle } from '@/src/components/ui';
import { useAppColors } from '@/src/hooks/useAppColors';
import { useFloodStore } from '@/src/store/appStore';
import type { Coordinates, PlaceSearchResult, TravelMode } from '@/src/types/domain';
import type { AnalyzedRoute } from '@/src/utils/routeRisk';
import { analyzeRoutes, recommendationMessage, sampleRoutePoints } from '@/src/utils/routeRisk';
import { getMapProvider } from '@/src/services/maps';
import type { RouteAlternative } from '@/src/services/maps';
import { mapPredictionFeaturesBatch } from '@/src/services/prediction/featureMapper';
import { getPredictionService } from '@/src/services/prediction';
import { captureAppError } from '@/src/services/diagnostics';

type AnnotatedRoute = AnalyzedRoute & { samplePoints: Coordinates[] };
const modeOptions: { value: TravelMode; label: string; icon: React.ComponentProps<typeof Feather>['name'] }[] = [
  { value: 'driving', label: 'Drive', icon: 'truck' },
  { value: 'cycling', label: 'Two-wheeler', icon: 'navigation' },
  { value: 'walking', label: 'Walk', icon: 'user' },
];

function RouteAutocomplete({
  label,
  value,
  onChange,
  onSelect,
  icon,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  onSelect: (place: PlaceSearchResult) => void;
  icon: 'circle' | 'map-pin';
}) {
  const colors = useAppColors();
  const settings = useFloodStore((state) => state.settings);
  const [results, setResults] = useState<PlaceSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (!focused || value.trim().length < 3) {
      setResults([]);
      return;
    }
    const timeout = setTimeout(() => {
      void (async () => {
        setLoading(true);
        try {
          const provider = await getMapProvider(settings);
          setResults(await provider.searchPlaces(value));
        } catch {
          setResults([]);
        } finally {
          setLoading(false);
        }
      })();
    }, 300);
    return () => clearTimeout(timeout);
  }, [focused, value, settings]);

  return (
    <View style={[styles.routeFieldWrap, { borderColor: colors.border, backgroundColor: colors.card }]}>
      <Feather name={icon} size={14} color={colors.primary} />
      <View style={{ flex: 1 }}>
        <TextInput
          accessibilityLabel={label}
          placeholder={label}
          placeholderTextColor={colors.mutedForeground}
          value={value}
          onChangeText={onChange}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 180)}
          style={[styles.routeInput, { color: colors.foreground }]}
          returnKeyType="search"
        />
        {loading ? <Text style={[styles.routeLoading, { color: colors.mutedForeground }]}>Searching places…</Text> : null}
      </View>
      {results.length > 0 ? (
        <View style={[styles.autocomplete, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {results.map((result, index) => (
            <Pressable
              key={`${result.latitude}-${result.longitude}-${index}`}
              accessibilityRole="button"
              onPress={() => {
                onSelect(result);
                setResults([]);
                setFocused(false);
              }}
              style={[
                styles.autocompleteItem,
                index < results.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth },
              ]}
            >
              <Text numberOfLines={1} style={[styles.autocompleteTitle, { color: colors.foreground }]}>{result.name}</Text>
              <Text numberOfLines={1} style={[styles.autocompleteAddress, { color: colors.mutedForeground }]}>{result.address}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
}

function RouteRiskMap({ route }: { route: AnnotatedRoute }) {
  const colors = useAppColors();
  const points = route.samplePoints;
  if (points.length < 2) {
    return (
      <View style={[styles.routeMap, { backgroundColor: colors.secondary }]}>
        <Text style={{ color: colors.mutedForeground, fontSize: 11 }}>Route preview unavailable.</Text>
      </View>
    );
  }
  const minLat = Math.min(...points.map((point) => point.latitude));
  const maxLat = Math.max(...points.map((point) => point.latitude));
  const minLon = Math.min(...points.map((point) => point.longitude));
  const maxLon = Math.max(...points.map((point) => point.longitude));
  const lonSpan = maxLon - minLon || 0.001;
  const latSpan = maxLat - minLat || 0.001;
  const project = (point: Coordinates) => ({
    x: 20 + ((point.longitude - minLon) / lonSpan) * 260,
    y: 18 + (1 - (point.latitude - minLat) / latSpan) * 104,
  });
  const projected = points.map(project);

  return (
    <View style={[styles.routeMap, { backgroundColor: colors.secondary }]}>
      <Svg width="100%" height="100%" viewBox="0 0 300 140">
        {projected.slice(1).map((point, index) => {
          const previous = projected[index]!;
          const risk = route.results[Math.min(index, route.results.length - 1)]?.risk_level ?? 'low';
          return (
            <Polyline
              key={`line-${index}`}
              points={`${previous.x},${previous.y} ${point.x},${point.y}`}
              fill="none"
              stroke={RISK_COLORS[risk]}
              strokeWidth={7}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          );
        })}
        <Circle cx={projected[0]!.x} cy={projected[0]!.y} r={8} fill="#ffffff" stroke="#0369a1" strokeWidth={4} />
        <Circle cx={projected[projected.length - 1]!.x} cy={projected[projected.length - 1]!.y} r={8} fill="#0369a1" stroke="#ffffff" strokeWidth={3} />
        {projected.slice(1, -1).map((point, index) => {
          const risk = route.results[index + 1]?.risk_level ?? 'low';
          return <Circle key={`spot-${index}`} cx={point.x} cy={point.y} r={4} fill={RISK_COLORS[risk]} stroke="#ffffff" strokeWidth={1.5} />;
        })}
      </Svg>
      <View style={styles.routeMapLegend}>
        {(['low', 'moderate', 'high', 'severe'] as const).map((level) => (
          <View key={level} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: RISK_COLORS[level] }]} />
            <Text style={[styles.legendLabel, { color: colors.mutedForeground }]}>{level}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function formatDistance(meters: number, units: 'km' | 'mi') {
  const amount = units === 'mi' ? meters / 1609.344 : meters / 1000;
  return `${amount.toFixed(amount < 10 ? 1 : 0)} ${units}`;
}

function formatDuration(seconds: number) {
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} min`;
  return `${Math.floor(minutes / 60)} hr ${minutes % 60} min`;
}

export default function RoutesScreen() {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ origin?: string; destination?: string }>();
  const settings = useFloodStore((state) => state.settings);
  const units = useFloodStore((state) => state.settings.units);
  const saveRoute = useFloodStore((state) => state.saveRoute);
  const savedRoutes = useFloodStore((state) => state.savedRoutes);
  const lastAlertedAt = useFloodStore((state) => state.lastAlertedAt);
  const setLastAlertedAt = useFloodStore((state) => state.setLastAlertedAt);
  const [originText, setOriginText] = useState('Park Street, Kolkata');
  const [destinationText, setDestinationText] = useState('Howrah Station, Kolkata');
  const [originPoint, setOriginPoint] = useState<Coordinates | null>(null);
  const [destinationPoint, setDestinationPoint] = useState<Coordinates | null>(null);
  const [waypointText, setWaypointText] = useState('');
  const [waypointPoint, setWaypointPoint] = useState<Coordinates | null>(null);
  const [showWaypoint, setShowWaypoint] = useState(false);
  const [mode, setMode] = useState<TravelMode>('driving');
  const [routes, setRoutes] = useState<AnnotatedRoute[]>([]);
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (params.origin) setOriginText(params.origin);
    if (params.destination) setDestinationText(params.destination);
  }, [params.origin, params.destination]);

  const selectedRoute = routes.find((route) => route.id === selectedRouteId) ?? routes.find((route) => route.recommended);
  const fastestRoute = useMemo(
    () => routes.reduce<AnnotatedRoute | null>((best, route) => !best || route.durationSeconds < best.durationSeconds ? route : best, null),
    [routes],
  );

  async function geocode(text: string, selected: Coordinates | null, provider: Awaited<ReturnType<typeof getMapProvider>>) {
    if (selected) return selected;
    const place = await provider.geocode(text.trim());
    if (!place) throw new Error(`Couldn't find “${text}”. Choose a place from search suggestions or try a fuller address.`);
    return { latitude: place.latitude, longitude: place.longitude };
  }

  async function compareRoutes() {
    setLoading(true);
    setError('');
    setRoutes([]);
    try {
      const provider = await getMapProvider(settings);
      const [origin, destination] = await Promise.all([
        geocode(originText, originPoint, provider),
        geocode(destinationText, destinationPoint, provider),
      ]);
      setOriginPoint(origin);
      setDestinationPoint(destination);
      const waypoints: Coordinates[] = [];
      if (showWaypoint && waypointText.trim()) {
        waypoints.push(await geocode(waypointText, waypointPoint, provider));
      }
      const alternatives = await provider.getRoutes(origin, destination, mode, waypoints);
      if (!alternatives.length) throw new Error('No routes found. Try different places or travel mode.');
      const samples = alternatives.map((route) => sampleRoutePoints(route.coordinates));
      const features = await mapPredictionFeaturesBatch(
        samples.flat(),
        { weatherEnabled: settings.weatherAutoFetch },
      );
      const predicted = await getPredictionService(settings).predictRoute(features);
      let cursor = 0;
      const predictions = samples.map((routeSamples) => {
        const group = predicted.slice(cursor, cursor + routeSamples.length);
        cursor += routeSamples.length;
        return group;
      });
      const analyzed = analyzeRoutes(alternatives, predictions).map((route, index) => ({
        ...route,
        samplePoints: samples[index] ?? [],
      }));
      setRoutes(analyzed);
      const recommended = analyzed.find((route) => route.recommended) ?? analyzed[0];
      setSelectedRouteId(recommended?.id ?? null);
      const normalizedOrigin = originText.trim().toLocaleLowerCase();
      const normalizedDestination = destinationText.trim().toLocaleLowerCase();
      const isSavedRoute = savedRoutes.some(
        (route) =>
          route.origin.trim().toLocaleLowerCase() === normalizedOrigin &&
          route.destination.trim().toLocaleLowerCase() === normalizedDestination,
      );
      const withinQuietHours =
        settings.quietHoursEnabled &&
        (new Date().getHours() >= 22 || new Date().getHours() < 7);
      const recentlyAlerted =
        lastAlertedAt && Date.now() - new Date(lastAlertedAt).getTime() < 60 * 60 * 1000;
      if (
        recommended &&
        isSavedRoute &&
        settings.alertsEnabled &&
        !withinQuietHours &&
        !recentlyAlerted &&
        recommended.averageRisk >=
          ({ low: 0.25, moderate: 0.5, high: 0.75, severe: 0.9 }[settings.riskThreshold]) &&
        Platform.OS !== 'web'
      ) {
        void Notifications.scheduleNotificationAsync({
          content: {
            title: 'Saved route risk has changed',
            body: `${originText} to ${destinationText} now has a ${Math.round(recommended.averageRisk * 100)}% average demo risk.`,
          },
          trigger: null,
        })
          .then(() => setLastAlertedAt(new Date().toISOString()))
          .catch(() => undefined);
      }
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (routeError) {
      captureAppError(routeError, { area: 'route-planning' });
      setError(routeError instanceof Error ? routeError.message : 'Route comparison failed.');
    } finally {
      setLoading(false);
    }
  }

  function swapPlaces() {
    setOriginText(destinationText);
    setDestinationText(originText);
    setOriginPoint(destinationPoint);
    setDestinationPoint(originPoint);
    void Haptics.selectionAsync();
  }

  async function saveSelectedRoute(route: AnnotatedRoute) {
    saveRoute({
      id: route.id,
      origin: originText,
      destination: destinationText,
      mode,
      distanceMeters: route.distanceMeters,
      durationSeconds: route.durationSeconds,
      savedAt: new Date().toISOString(),
    });
    Alert.alert('Route saved', 'Find it again in Saved.');
  }

  async function startNavigation(route: AnnotatedRoute) {
    const destination = destinationPoint ?? DEFAULT_MAP_CENTER;
    const googleNavigation = `google.navigation:q=${destination.latitude},${destination.longitude}&mode=${mode === 'walking' ? 'w' : mode === 'cycling' ? 'b' : 'd'}`;
    const webNavigation = `https://www.google.com/maps/dir/?api=1&destination=${destination.latitude},${destination.longitude}&travelmode=${mode === 'walking' ? 'walking' : mode === 'cycling' ? 'bicycling' : 'driving'}`;
    try {
      if (Platform.OS === 'android' && (await Linking.canOpenURL(googleNavigation))) {
        await Linking.openURL(googleNavigation);
      } else {
        await Linking.openURL(webNavigation);
      }
    } catch {
      Alert.alert('Could not open maps', 'Install a maps app or check your internet connection.');
    }
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + 18, paddingBottom: Math.max(insets.bottom, 18) + 90 },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        <ScreenTitle
          title="Route planner"
          subtitle="Compare up to three routes by predicted water risk."
          action={
            <View style={[styles.titleIcon, { backgroundColor: colors.accent }]}>
              <Feather name="navigation" size={21} color={colors.primary} />
            </View>
          }
        />
        <AppCard style={styles.routeForm}>
          <View style={styles.inputPair}>
            <View style={styles.connector}>
              <View style={[styles.originDot, { borderColor: colors.primary }]} />
              <View style={[styles.connectorLine, { backgroundColor: colors.border }]} />
              <View style={[styles.destinationDot, { backgroundColor: colors.primary }]} />
            </View>
            <View style={{ flex: 1, gap: 9 }}>
              <RouteAutocomplete
                label="Starting point"
                value={originText}
                icon="circle"
                onChange={(value) => { setOriginText(value); setOriginPoint(null); }}
                onSelect={(place) => { setOriginText(place.name); setOriginPoint(place); }}
              />
              <RouteAutocomplete
                label="Destination"
                value={destinationText}
                icon="map-pin"
                onChange={(value) => { setDestinationText(value); setDestinationPoint(null); }}
                onSelect={(place) => { setDestinationText(place.name); setDestinationPoint(place); }}
              />
            </View>
            <IconButton icon="repeat" label="Swap origin and destination" onPress={swapPlaces} color={colors.primary} />
          </View>
          {showWaypoint ? (
            <View style={{ marginTop: 11, marginLeft: 28 }}>
              <RouteAutocomplete
                label="Add a stop"
                value={waypointText}
                icon="map-pin"
                onChange={(value) => { setWaypointText(value); setWaypointPoint(null); }}
                onSelect={(place) => { setWaypointText(place.name); setWaypointPoint(place); }}
              />
            </View>
          ) : (
            <Pressable
              accessibilityRole="button"
              onPress={() => setShowWaypoint(true)}
              style={styles.addStop}
            >
              <Feather name="plus" size={14} color={colors.primary} />
              <Text style={[styles.addStopText, { color: colors.primary }]}>Add a stop</Text>
            </Pressable>
          )}
          <View style={styles.modeRow}>
            {modeOptions.map((option) => {
              const active = mode === option.value;
              return (
                <Pressable
                  key={option.value}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: active }}
                  onPress={() => setMode(option.value)}
                  style={[
                    styles.modeChoice,
                    {
                      backgroundColor: active ? colors.primary : colors.secondary,
                    },
                  ]}
                >
                  <Feather name={option.icon} size={15} color={active ? colors.primaryForeground : colors.secondaryForeground} />
                  <Text style={[styles.modeText, { color: active ? colors.primaryForeground : colors.secondaryForeground }]}>{option.label}</Text>
                </Pressable>
              );
            })}
          </View>
          {mode !== 'driving' ? (
            <Text style={[styles.providerNote, { color: colors.mutedForeground }]}>
              Free OSRM routes are road-based. Travel time is adjusted for this mode; use a mode-specific router for production routing.
            </Text>
          ) : null}
          <ActionButton
            label="Compare safer routes"
            icon="shuffle"
            onPress={() => void compareRoutes()}
            loading={loading}
            disabled={!originText.trim() || !destinationText.trim()}
            style={{ marginTop: 14 }}
          />
        </AppCard>

        {error ? (
          <AppCard style={[styles.errorCard, { borderColor: '#f2c7c4' }]}>
            <View style={styles.errorTitle}>
              <Feather name="alert-circle" size={17} color={colors.destructive} />
              <Text style={[styles.errorHeading, { color: colors.destructive }]}>Could not compare routes</Text>
            </View>
            <Text style={[styles.errorCopy, { color: colors.mutedForeground }]}>{error}</Text>
            <Pressable accessibilityRole="button" onPress={() => void compareRoutes()} style={{ paddingVertical: 5 }}>
              <Text style={[styles.retry, { color: colors.primary }]}>Try again</Text>
            </Pressable>
          </AppCard>
        ) : null}

        {selectedRoute ? (
          <>
            <View style={styles.resultsHeading}>
              <View>
                <Eyebrow>Risk-aware comparison</Eyebrow>
                <Text style={[styles.resultsTitle, { color: colors.foreground }]}>{routes.length} routes found</Text>
              </View>
              <View style={[styles.demoTag, { backgroundColor: colors.accent }]}>
                <View style={[styles.demoDot, { backgroundColor: colors.primary }]} />
                <Text style={[styles.demoTagText, { color: colors.accentForeground }]}>DEMO MODEL</Text>
              </View>
            </View>
            <AppCard style={styles.previewCard}>
              <View style={styles.previewHeading}>
                <View>
                  <Text style={[styles.previewTitle, { color: colors.foreground }]}>{selectedRoute.recommended ? 'Recommended route' : 'Selected route'}</Text>
                  <Text style={[styles.previewSub, { color: colors.mutedForeground }]}>Road risk segments are color-coded</Text>
                </View>
                <RiskBadge level={selectedRoute.results.find((item) => item.probability === selectedRoute.maxRisk)?.risk_level ?? 'low'} />
              </View>
              <RouteRiskMap route={selectedRoute} />
              {fastestRoute ? (
                <Text style={[styles.recommendation, { color: colors.secondaryForeground }]}>
                  {recommendationMessage(selectedRoute, fastestRoute)}
                </Text>
              ) : null}
            </AppCard>
            <View style={styles.optionHeading}>
              <Text style={[styles.optionHeadingTitle, { color: colors.foreground }]}>Route options</Text>
              <Text style={[styles.optionHeadingMeta, { color: colors.mutedForeground }]}>Safer routes stay within 25% of the fastest time</Text>
            </View>
            {routes.map((route, index) => (
              <Pressable
                key={route.id}
                accessibilityRole="button"
                accessibilityState={{ selected: selectedRoute.id === route.id }}
                onPress={() => setSelectedRouteId(route.id)}
                style={({ pressed }) => [
                  styles.routeOption,
                  {
                    backgroundColor: colors.card,
                    borderColor: selectedRoute.id === route.id ? colors.primary : colors.border,
                    opacity: pressed ? 0.88 : 1,
                  },
                ]}
              >
                <View style={styles.routeOptionTop}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.routeName, { color: colors.foreground }]}>Route {index + 1}</Text>
                    <View style={styles.routeMeta}>
                      <Feather name="clock" size={12} color={colors.mutedForeground} />
                      <Text style={[styles.routeMetaText, { color: colors.mutedForeground }]}>{formatDuration(route.durationSeconds)}</Text>
                      <View style={[styles.metaDot, { backgroundColor: colors.border }]} />
                      <Text style={[styles.routeMetaText, { color: colors.mutedForeground }]}>{formatDistance(route.distanceMeters, units)}</Text>
                    </View>
                  </View>
                  <View style={styles.routeRiskInfo}>
                    <Text style={[styles.routeRiskPercent, { color: RISK_COLORS[route.results.find((item) => item.probability === route.maxRisk)?.risk_level ?? 'low'] }]}>
                      {Math.round(route.averageRisk * 100)}%
                    </Text>
                    <Text style={[styles.routeRiskCaption, { color: colors.mutedForeground }]}>avg risk</Text>
                  </View>
                </View>
                <View style={styles.routeBadgeRow}>
                  {route.recommended ? <View style={[styles.optionBadge, { backgroundColor: colors.accent }]}><Feather name="shield" size={11} color={colors.accentForeground} /><Text style={[styles.optionBadgeText, { color: colors.accentForeground }]}>Safest within 25%</Text></View> : null}
                  {route.fastest ? <View style={[styles.optionBadge, { backgroundColor: colors.secondary }]}><Feather name="zap" size={11} color={colors.secondaryForeground} /><Text style={[styles.optionBadgeText, { color: colors.secondaryForeground }]}>Fastest</Text></View> : null}
                  <Text style={[styles.riskyCount, { color: route.highRiskSpots ? colors.destructive : colors.mutedForeground }]}>
                    {route.highRiskSpots} high-risk {route.highRiskSpots === 1 ? 'spot' : 'spots'}
                  </Text>
                </View>
                {selectedRoute.id === route.id ? (
                  <View style={styles.routeActions}>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => void saveSelectedRoute(route)}
                      style={[styles.saveRoute, { backgroundColor: colors.secondary }]}
                    >
                      <Feather name="bookmark" size={14} color={colors.secondaryForeground} />
                      <Text style={[styles.saveRouteText, { color: colors.secondaryForeground }]}>Save</Text>
                    </Pressable>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => void startNavigation(route)}
                      style={[styles.startNav, { backgroundColor: colors.primary }]}
                    >
                      <Feather name="navigation" size={14} color={colors.primaryForeground} />
                      <Text style={[styles.startNavText, { color: colors.primaryForeground }]}>Start navigation</Text>
                    </Pressable>
                  </View>
                ) : null}
              </Pressable>
            ))}
          </>
        ) : (
          <AppCard style={styles.emptyCard}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
              <Feather name="shuffle" size={21} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Plan around the water</Text>
            <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
              Enter two places to compare available routes against predicted rain-related risk.
            </Text>
            <View style={styles.emptySteps}>
              <Text style={[styles.emptyStep, { color: colors.mutedForeground }]}>1. Choose places from search</Text>
              <Text style={[styles.emptyStep, { color: colors.mutedForeground }]}>2. Pick a travel mode</Text>
              <Text style={[styles.emptyStep, { color: colors.mutedForeground }]}>3. Compare risk, ETA and distance</Text>
            </View>
          </AppCard>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18 },
  titleIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  routeForm: { padding: 14, marginBottom: 21, zIndex: 2 },
  inputPair: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  connector: { width: 19, height: 101, alignItems: 'center', justifyContent: 'center' },
  originDot: { width: 11, height: 11, borderRadius: 6, borderWidth: 3, backgroundColor: '#ffffff' },
  destinationDot: { width: 8, height: 8, borderRadius: 4 },
  connectorLine: { height: 45, width: 1, marginVertical: 3 },
  routeFieldWrap: { minHeight: 48, borderRadius: 14, borderWidth: 1, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 9, zIndex: 8 },
  routeInput: { fontFamily: 'Inter_500Medium', fontSize: 12, height: 46, padding: 0 },
  routeLoading: { fontFamily: 'Inter_400Regular', fontSize: 9, paddingBottom: 5 },
  autocomplete: { position: 'absolute', top: 49, left: -1, right: -1, borderWidth: 1, borderRadius: 14, zIndex: 30, elevation: 8, overflow: 'hidden' },
  autocompleteItem: { minHeight: 50, justifyContent: 'center', paddingHorizontal: 11, gap: 3 },
  autocompleteTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  autocompleteAddress: { fontFamily: 'Inter_400Regular', fontSize: 9 },
  addStop: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 11, marginLeft: 30, minHeight: 30 },
  addStopText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  modeRow: { flexDirection: 'row', gap: 7, marginTop: 14 },
  modeChoice: { flex: 1, minHeight: 41, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, borderRadius: 13, paddingHorizontal: 4 },
  modeText: { fontFamily: 'Inter_600SemiBold', fontSize: 9 },
  providerNote: { fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 14, marginTop: 8 },
  errorCard: { marginBottom: 16, padding: 14 },
  errorTitle: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  errorHeading: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  errorCopy: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 7 },
  retry: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  resultsHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 11 },
  resultsTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, marginTop: 4 },
  demoTag: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6 },
  demoDot: { height: 6, width: 6, borderRadius: 3 },
  demoTagText: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.6 },
  previewCard: { marginBottom: 17, padding: 13 },
  previewHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  previewTitle: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  previewSub: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 3 },
  routeMap: { height: 155, borderRadius: 15, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' },
  routeMapLegend: { position: 'absolute', right: 9, bottom: 8, paddingHorizontal: 7, paddingVertical: 5, flexDirection: 'row', gap: 7, borderRadius: 9, backgroundColor: '#ffffffec' },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  legendDot: { width: 5, height: 5, borderRadius: 3 },
  legendLabel: { fontFamily: 'Inter_500Medium', fontSize: 7, textTransform: 'capitalize' },
  recommendation: { fontFamily: 'Inter_600SemiBold', fontSize: 10, marginTop: 9 },
  optionHeading: { marginBottom: 10 },
  optionHeadingTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  optionHeadingMeta: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 3 },
  routeOption: { borderWidth: 1, borderRadius: 19, padding: 14, marginBottom: 10 },
  routeOptionTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  routeName: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  routeMeta: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 7 },
  routeMetaText: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  metaDot: { width: 3, height: 3, borderRadius: 2 },
  routeRiskInfo: { alignItems: 'flex-end' },
  routeRiskPercent: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  routeRiskCaption: { fontFamily: 'Inter_500Medium', fontSize: 8, marginTop: 1 },
  routeBadgeRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6, marginTop: 11 },
  optionBadge: { borderRadius: 99, flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 5, paddingHorizontal: 8 },
  optionBadgeText: { fontFamily: 'Inter_600SemiBold', fontSize: 9 },
  riskyCount: { fontFamily: 'Inter_500Medium', fontSize: 9, marginLeft: 'auto' },
  routeActions: { flexDirection: 'row', gap: 8, marginTop: 12 },
  saveRoute: { height: 39, borderRadius: 12, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 6 },
  saveRouteText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  startNav: { height: 39, borderRadius: 12, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, flex: 1 },
  startNavText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  emptyCard: { alignItems: 'center', paddingVertical: 25, paddingHorizontal: 21 },
  emptyIcon: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 13 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  emptyCopy: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 6, maxWidth: 280 },
  emptySteps: { alignSelf: 'stretch', gap: 9, marginTop: 20, paddingTop: 16, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#dce8ec' },
  emptyStep: { fontFamily: 'Inter_500Medium', fontSize: 10 },
});
