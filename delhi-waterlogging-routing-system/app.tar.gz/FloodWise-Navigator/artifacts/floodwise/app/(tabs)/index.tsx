import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Image,
  Keyboard,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
  useColorScheme,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as Network from 'expo-network';
import * as Notifications from 'expo-notifications';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import { DEFAULT_MAP_CENTER, RISK_COLORS, riskLevelForProbability } from '@/src/config/constants';
import { useAppColors } from '@/src/hooks/useAppColors';
import { useFloodStore } from '@/src/store/appStore';
import type { Coordinates, PlaceSearchResult, RiskLevel } from '@/src/types/domain';
import { MapCanvas } from '@/src/components/MapCanvas';
import { RiskGauge } from '@/src/components/RiskGauge';
import { ActionButton, AppCard, IconButton, RiskBadge } from '@/src/components/ui';
import { getGoogleMapsKey, getMapProvider } from '@/src/services/maps';
import { getPredictionService } from '@/src/services/prediction';
import { mapPredictionFeatures } from '@/src/services/prediction/featureMapper';
import { captureAppError } from '@/src/services/diagnostics';

type SelectedPlace = Coordinates & { name: string; address?: string };
const DEMO_MARKERS = [
  { latitude: 22.5664, longitude: 88.3522, probability: 0.32, riskLevel: 'moderate' as const },
  { latitude: 22.5796, longitude: 88.3719, probability: 0.68, riskLevel: 'high' as const },
  { latitude: 22.5516, longitude: 88.3444, probability: 0.82, riskLevel: 'severe' as const },
  { latitude: 22.5899, longitude: 88.3451, probability: 0.22, riskLevel: 'low' as const },
];

function getRiskCutoff(level: RiskLevel) {
  return { low: 0.25, moderate: 0.5, high: 0.75, severe: 0.9 }[level];
}

async function getDeviceLocation(): Promise<Coordinates> {
  if (Platform.OS === 'web' && typeof navigator !== 'undefined' && navigator.geolocation) {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) =>
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          }),
        (error) => reject(new Error(error.message)),
        { enableHighAccuracy: true, timeout: 12_000 },
      );
    });
  }
  const permission = await Location.requestForegroundPermissionsAsync();
  if (!permission.granted) {
    if (!permission.canAskAgain && Platform.OS !== 'web') {
      Alert.alert(
        'Location is off',
        'Allow location access in your device settings, or choose any place on the map.',
        [
          { text: 'Not now', style: 'cancel' },
          { text: 'Open Settings', onPress: () => void Linking.openSettings() },
        ],
      );
    }
    throw new Error('Location permission was not granted.');
  }
  const position = await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy.Balanced,
  });
  return {
    latitude: position.coords.latitude,
    longitude: position.coords.longitude,
  };
}

function useOnboarding(
  visible: boolean,
  onFinish: () => void,
  colors: ReturnType<typeof useAppColors>,
) {
  const [step, setStep] = useState(0);
  const pages = [
    {
      icon: 'cloud-rain' as const,
      title: 'See water risk before you go',
      description: 'Check a place or road segment using rainfall, elevation and local drainage signals.',
    },
    {
      icon: 'navigation' as const,
      title: 'Compare safer ways there',
      description: 'Review up to three route options and see where higher-risk stretches appear.',
    },
    {
      icon: 'shield' as const,
      title: 'Demo mode is ready',
      description: 'Predictions are simulated for now. Add your trained model and map key later in Settings.',
    },
  ];
  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onFinish}>
      <View style={styles.onboardingBackdrop}>
        <View style={[styles.onboardingCard, { backgroundColor: colors.card }]}>
          <View style={[styles.onboardingIcon, { backgroundColor: colors.accent }]}>
            <Feather name={pages[step]!.icon} size={28} color={colors.primary} />
          </View>
          <Text style={[styles.onboardingTitle, { color: colors.foreground }]}>
            {pages[step]!.title}
          </Text>
          <Text style={[styles.onboardingBody, { color: colors.mutedForeground }]}>
            {pages[step]!.description}
          </Text>
          <View style={styles.onboardingDots}>
            {pages.map((page, index) => (
              <View
                key={page.title}
                style={[
                  styles.onboardingDot,
                  { backgroundColor: index === step ? colors.primary : colors.border },
                ]}
              />
            ))}
          </View>
          <ActionButton
            label={step === pages.length - 1 ? 'Start exploring' : 'Continue'}
            icon={step === pages.length - 1 ? 'arrow-right' : undefined}
            onPress={() => {
              if (step < pages.length - 1) setStep(step + 1);
              else onFinish();
            }}
          />
          <Pressable
            accessibilityRole="button"
            onPress={onFinish}
            style={{ paddingVertical: 15, alignItems: 'center' }}
          >
            <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }}>
              Skip introduction
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

function PhotoReportModal({
  visible,
  point,
  onClose,
}: {
  visible: boolean;
  point: SelectedPlace;
  onClose: () => void;
}) {
  const colors = useAppColors();
  const addReport = useFloodStore((state) => state.addReport);
  const [severity, setSeverity] = useState<RiskLevel>('high');
  const [description, setDescription] = useState('');
  const [photoUri, setPhotoUri] = useState<string | undefined>();

  async function addPhoto() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Photo access needed', 'Allow photo access to attach an optional image.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.75,
    });
    if (!result.canceled) setPhotoUri(result.assets[0]?.uri);
  }

  function submit() {
    addReport({
      id: `${Date.now()}`,
      latitude: point.latitude,
      longitude: point.longitude,
      severity,
      description: description.trim(),
      photoUri,
      createdAt: new Date().toISOString(),
    });
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setDescription('');
    setPhotoUri(undefined);
    onClose();
    Alert.alert('Report saved', 'Your report is stored on this device and has not been sent to a server.');
  }

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.modalBackdrop}>
        <SafeAreaView style={[styles.modalCard, { backgroundColor: colors.background }]}>
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Report waterlogging</Text>
              <Text style={[styles.modalSub, { color: colors.mutedForeground }]}>{point.name}</Text>
            </View>
            <IconButton icon="x" label="Close report" onPress={onClose} />
          </View>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>How bad is it?</Text>
          <View style={styles.severityRow}>
            {(['moderate', 'high', 'severe'] as RiskLevel[]).map((value) => (
              <Pressable
                key={value}
                accessibilityRole="radio"
                accessibilityState={{ selected: severity === value }}
                onPress={() => setSeverity(value)}
                style={[
                  styles.severityChoice,
                  {
                    borderColor: severity === value ? RISK_COLORS[value] : colors.border,
                    backgroundColor: severity === value ? `${RISK_COLORS[value]}18` : colors.card,
                  },
                ]}
              >
                <Text style={{ color: colors.foreground, fontFamily: 'Inter_600SemiBold', fontSize: 12 }}>
                  {value.charAt(0).toUpperCase() + value.slice(1)}
                </Text>
              </Pressable>
            ))}
          </View>
          <TextInput
            accessibilityLabel="Report details"
            placeholder="Add a note (optional)"
            placeholderTextColor={colors.mutedForeground}
            value={description}
            onChangeText={setDescription}
            multiline
            maxLength={240}
            style={[
              styles.reportInput,
              { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border },
            ]}
          />
          {photoUri ? <Image source={{ uri: photoUri }} style={styles.reportPhoto} /> : null}
          <ActionButton label={photoUri ? 'Change photo' : 'Add a photo'} icon="image" secondary onPress={() => void addPhoto()} />
          <ActionButton label="Save community report" icon="send" onPress={submit} style={{ marginTop: 12 }} />
          <Text style={[styles.localNote, { color: colors.mutedForeground }]}>
            Stored on this phone only. No account or server is needed.
          </Text>
        </SafeAreaView>
      </View>
    </Modal>
  );
}

function RiskDetailsModal({
  visible,
  point,
  result,
  onClose,
  onShare,
  onReport,
}: {
  visible: boolean;
  point: SelectedPlace;
  result?: {
    probability: number;
    risk_level: RiskLevel;
    confidence: number;
    factors: { name: string; impact: number }[];
    forecast?: { time: string; probability: number }[];
    model_version: string;
  };
  onClose: () => void;
  onShare: () => void;
  onReport: () => void;
}) {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={[styles.detailsScreen, { backgroundColor: colors.background }]}>
        <View style={styles.detailsHeader}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.detailsEyebrow, { color: colors.mutedForeground }]}>LOCAL WATERLOGGING</Text>
            <Text style={[styles.detailsTitle, { color: colors.foreground }]} numberOfLines={1}>{point.name}</Text>
          </View>
          <IconButton icon="x" label="Close risk details" onPress={onClose} />
        </View>
        <ScrollView contentContainerStyle={{ paddingBottom: Math.max(insets.bottom, 18) + 20 }}>
          {result ? (
            <>
              <View style={styles.detailsGaugeWrap}>
                <RiskGauge
                  size={150}
                  probability={result.probability}
                  riskLevel={result.risk_level}
                  color={RISK_COLORS[result.risk_level]}
                />
                <RiskBadge level={result.risk_level} />
                <Text style={[styles.detailsConfidence, { color: colors.mutedForeground }]}>
                  {Math.round(result.confidence * 100)}% model confidence
                </Text>
              </View>
              <AppCard style={styles.detailsCard}>
                <Text style={[styles.detailsSectionTitle, { color: colors.foreground }]}>What is driving the estimate?</Text>
                {result.factors.length ? result.factors.map((factor) => (
                  <View key={factor.name} style={styles.factorRow}>
                    <View style={styles.factorLabelRow}>
                      <Text style={[styles.detailsFactorName, { color: colors.foreground }]}>{factor.name}</Text>
                      <Text style={[styles.detailsFactorValue, { color: colors.mutedForeground }]}>{Math.round(factor.impact * 100)}%</Text>
                    </View>
                    <View style={[styles.detailsTrack, { backgroundColor: colors.muted }]}>
                      <View
                        style={[
                          styles.detailsFill,
                          {
                            width: `${Math.max(4, Math.min(100, factor.impact * 100))}%`,
                            backgroundColor: RISK_COLORS[riskLevelForProbability(factor.impact)],
                          },
                        ]}
                      />
                    </View>
                  </View>
                )) : (
                  <Text style={[styles.detailsEmpty, { color: colors.mutedForeground }]}>
                    This cached result has no factor breakdown.
                  </Text>
                )}
              </AppCard>
              {result.forecast?.length ? (
                <AppCard style={styles.detailsCard}>
                  <Text style={[styles.detailsSectionTitle, { color: colors.foreground }]}>Risk outlook</Text>
                  <View style={styles.forecastRow}>
                    {result.forecast.map((item) => (
                      <View key={item.time} style={[styles.forecastItem, { backgroundColor: colors.secondary }]}>
                        <Text style={[styles.forecastTime, { color: colors.mutedForeground }]}>{item.time}</Text>
                        <Text style={[styles.forecastPercent, { color: RISK_COLORS[riskLevelForProbability(item.probability)] }]}>
                          {Math.round(item.probability * 100)}%
                        </Text>
                      </View>
                    ))}
                  </View>
                </AppCard>
              ) : null}
              <Text style={[styles.detailsFootnote, { color: colors.mutedForeground }]}>
                {result.model_version} · Updated just now. Demo estimates are not official warnings.
              </Text>
            </>
          ) : (
            <Text style={[styles.detailsEmpty, { color: colors.mutedForeground }]}>A risk result is not available yet.</Text>
          )}
          <View style={styles.detailsActions}>
            <ActionButton label="Share estimate" icon="share-2" secondary onPress={onShare} style={{ flex: 1 }} />
            <ActionButton label="Report waterlogging" icon="alert-triangle" onPress={onReport} style={{ flex: 1 }} />
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

export default function ExploreScreen() {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams<{ lat?: string; lon?: string; label?: string }>();
  const settings = useFloodStore((state) => state.settings);
  const savedPlaces = useFloodStore((state) => state.savedPlaces);
  const savePlace = useFloodStore((state) => state.savePlace);
  const addCheck = useFloodStore((state) => state.addCheck);
  const finishOnboarding = useFloodStore((state) => state.finishOnboarding);
  const onboardingComplete = useFloodStore((state) => state.onboardingComplete);
  const lastAlertedAt = useFloodStore((state) => state.lastAlertedAt);
  const recentChecks = useFloodStore((state) => state.recentChecks);
  const setLastAlertedAt = useFloodStore((state) => state.setLastAlertedAt);
  const [selected, setSelected] = useState<SelectedPlace>({
    ...DEFAULT_MAP_CENTER,
    name: 'Central Kolkata',
  });
  const [deviceLocation, setDeviceLocation] = useState<Coordinates | null>(null);
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState<PlaceSearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [showRisk, setShowRisk] = useState(true);
  const [showMap, setShowMap] = useState(true);
  const [bannerVisible, setBannerVisible] = useState(true);
  const [googleKeyAvailable, setGoogleKeyAvailable] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [mapZoom, setMapZoom] = useState(14);
  const [rainfall, setRainfall] = useState<number | null>(null);
  const [rainDuration, setRainDuration] = useState<number | null>(null);
  const [reportVisible, setReportVisible] = useState(false);
  const [detailsVisible, setDetailsVisible] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [welcomeHandled, setWelcomeHandled] = useState(false);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (Platform.OS !== 'web' && !onboardingComplete && !welcomeHandled) {
      setShowWelcome(true);
    }
  }, [onboardingComplete, welcomeHandled]);

  useEffect(() => {
    if (!params.lat || !params.lon) return;
    const latitude = Number(params.lat);
    const longitude = Number(params.lon);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return;
    setSelected({
      latitude,
      longitude,
      name: params.label || 'Selected place',
    });
  }, [params.lat, params.lon, params.label]);

  useEffect(() => {
    void getGoogleMapsKey().then((key) => setGoogleKeyAvailable(Boolean(key)));
  }, [settings.mapMode]);

  useEffect(() => {
    if (Platform.OS === 'web') {
      const update = () => setIsOnline(navigator.onLine);
      update();
      window.addEventListener('online', update);
      window.addEventListener('offline', update);
      return () => {
        window.removeEventListener('online', update);
        window.removeEventListener('offline', update);
      };
    }
    void Network.getNetworkStateAsync().then((state) => setIsOnline(state.isConnected !== false));
    const subscription = Network.addNetworkStateListener((state) =>
      setIsOnline(state.isConnected !== false),
    );
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    if (searchText.trim().length < 3) {
      setSearchResults([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    searchTimer.current = setTimeout(() => {
      void (async () => {
        try {
          const provider = await getMapProvider(settings);
          const results = await provider.searchPlaces(searchText);
          setSearchResults(results);
        } catch (error) {
          captureAppError(error, { area: 'map-search' });
          setSearchResults([]);
          Alert.alert(
            'Search unavailable',
            error instanceof Error ? error.message : 'Try again in a moment.',
          );
        } finally {
          setSearching(false);
        }
      })();
    }, 300);
    return () => {
      if (searchTimer.current) clearTimeout(searchTimer.current);
    };
  }, [searchText, settings]);

  const riskQuery = useQuery({
    queryKey: [
      'place-risk',
      selected.latitude.toFixed(4),
      selected.longitude.toFixed(4),
      settings.weatherAutoFetch,
      rainfall,
      rainDuration,
      settings.predictionMode,
      settings.predictionApiUrl,
      isOnline,
    ],
    queryFn: async () => {
      const cachedCheck = [...recentChecks]
        .reverse()
        .find(
          (check) =>
            Math.abs(check.latitude - selected.latitude) < 0.0002 &&
            Math.abs(check.longitude - selected.longitude) < 0.0002,
        );
      if (!isOnline && cachedCheck) {
        return {
          input: await mapPredictionFeatures(selected, {
            weatherEnabled: false,
            networkAvailable: false,
          }),
          result: {
            probability: cachedCheck.probability,
            risk_level: cachedCheck.riskLevel,
            confidence: 0.5,
            factors: [],
            model_version: 'Cached local estimate',
          },
        };
      }
      const input = await mapPredictionFeatures(selected, {
        weatherEnabled: settings.weatherAutoFetch && isOnline,
        networkAvailable: isOnline,
        overrides:
          rainfall !== null || rainDuration !== null
            ? { rainfallIntensity: rainfall ?? undefined, rainfallDuration: rainDuration ?? undefined }
            : undefined,
      });
      const result = await getPredictionService(settings).predictPoint(input);
      return { input, result };
    },
    staleTime: 25_000,
    retry: isOnline ? 1 : 0,
  });
  const risk = riskQuery.data?.result;
  useEffect(() => {
    if (riskQuery.error) captureAppError(riskQuery.error, { area: 'place-risk' });
  }, [riskQuery.error]);
  const probability = risk?.probability ?? 0;
  const riskLevel = risk?.risk_level ?? 'moderate';
  const dynamicMarker = useMemo(
    () => (risk ? [{ ...selected, probability, riskLevel }] : []),
    [risk, selected, probability, riskLevel],
  );
  const markers = showRisk ? [...DEMO_MARKERS, ...dynamicMarker] : [];
  const mapModeLabel = settings.mapMode === 'google' && googleKeyAvailable ? 'Google search' : 'Free map';

  useEffect(() => {
    if (!risk || !selected) return;
    addCheck({
      id: `${Date.now()}-${selected.latitude.toFixed(3)}`,
      latitude: selected.latitude,
      longitude: selected.longitude,
      name: selected.name,
      probability: risk.probability,
      riskLevel: risk.risk_level,
      checkedAt: new Date().toISOString(),
    });
  }, [risk, selected, addCheck]);

  useEffect(() => {
    if (!risk || !selected) return;
    const alreadyExists = savedPlaces.some(
      (place) =>
        Math.abs(place.latitude - selected.latitude) < 0.0002 &&
        Math.abs(place.longitude - selected.longitude) < 0.0002,
    );
    const withinQuietHours = settings.quietHoursEnabled && (new Date().getHours() >= 22 || new Date().getHours() < 7);
    const recentlyAlerted =
      lastAlertedAt && Date.now() - new Date(lastAlertedAt).getTime() < 60 * 60 * 1000;
    if (
      settings.alertsEnabled &&
      alreadyExists &&
      !withinQuietHours &&
      !recentlyAlerted &&
      risk.probability >= getRiskCutoff(settings.riskThreshold) &&
      Platform.OS !== 'web'
    ) {
      void Notifications.scheduleNotificationAsync({
        content: {
          title: `${selected.name}: ${risk.risk_level} waterlogging risk`,
          body: `The current demo estimate is ${Math.round(risk.probability * 100)}%. Review local conditions before travelling.`,
          data: { latitude: selected.latitude, longitude: selected.longitude },
        },
        trigger: null,
      }).then(() => setLastAlertedAt(new Date().toISOString())).catch(() => undefined);
    }
  }, [risk, selected, savedPlaces, settings, lastAlertedAt, setLastAlertedAt]);

  function selectResult(result: PlaceSearchResult) {
    Keyboard.dismiss();
    setSearchResults([]);
    setSearchText('');
    setSelected({
      name: result.name,
      address: result.address,
      latitude: result.latitude,
      longitude: result.longitude,
    });
    setRainfall(null);
    setRainDuration(null);
    void Haptics.selectionAsync();
  }

  async function useLocation() {
    try {
      const point = await getDeviceLocation();
      setDeviceLocation(point);
      setSelected({ ...point, name: 'My location' });
      setRainfall(null);
      setRainDuration(null);
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    } catch (error) {
      Alert.alert(
        'Could not get your location',
        error instanceof Error ? error.message : 'Choose a point on the map instead.',
      );
    }
  }

  async function pinMapPoint(point: Coordinates) {
    setSelected({ ...point, name: 'Map point' });
    setRainfall(null);
    setRainDuration(null);
    try {
      const provider = await getMapProvider(settings);
      const place = await provider.reverseGeocode(point);
      if (place) {
        setSelected({ ...place, latitude: point.latitude, longitude: point.longitude });
      }
    } catch {
      // Keep the selected coordinate visible if reverse geocoding is offline.
    }
  }

  function saveCurrentPlace() {
    savePlace({
      id: `${selected.latitude.toFixed(5)}-${selected.longitude.toFixed(5)}`,
      name: selected.name,
      latitude: selected.latitude,
      longitude: selected.longitude,
      category: 'custom',
      addedAt: new Date().toISOString(),
    });
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert('Place saved', `${selected.name} is now in your saved places.`);
  }

  async function shareRisk() {
    if (!risk) return;
    await Share.share({
      message: `FloodWise demo estimate for ${selected.name}: ${Math.round(risk.probability * 100)}% ${risk.risk_level} waterlogging risk. Check local conditions before travelling.`,
    });
  }

  const completeWelcome = () => {
    setShowWelcome(false);
    setWelcomeHandled(true);
    finishOnboarding();
  };
  const systemColorScheme = useColorScheme();
  const statusStyle =
    settings.theme === 'dark' ||
    (settings.theme === 'system' && systemColorScheme === 'dark')
      ? 'light'
      : 'dark';

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style={statusStyle} />
      <MapCanvas
        center={selected}
        markers={markers}
        showRisk={showRisk}
        showMap={showMap}
        zoom={mapZoom}
        location={deviceLocation}
        onMapPress={(point) => void pinMapPoint(point)}
        onMarkerPress={(marker) =>
          void pinMapPoint({ latitude: marker.latitude, longitude: marker.longitude })
        }
      />
      <View style={[styles.topOverlay, { top: insets.top + 9 }]}>
        <View style={styles.brandRow}>
          <View style={styles.brandMark}>
            <Feather name="droplet" size={19} color="#ffffff" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.brandName}>FloodWise</Text>
            <Text style={styles.brandMeta}>{mapModeLabel} · simulated risk</Text>
          </View>
          <IconButton
            icon="layers"
            label={showMap ? 'Hide base map' : 'Show base map'}
            color="#0d3441"
            style={styles.floatIcon}
            onPress={() => setShowMap((value) => !value)}
          />
          <IconButton
            icon={showRisk ? 'eye' : 'eye-off'}
            label={showRisk ? 'Hide risk overlay' : 'Show risk overlay'}
            color="#0d3441"
            style={styles.floatIcon}
            onPress={() => setShowRisk((value) => !value)}
          />
        </View>
        {!isOnline ? (
          <View style={styles.offlineBanner}>
            <Feather name="wifi-off" size={14} color="#ffffff" />
            <Text style={styles.offlineText}>Offline · showing saved results where available</Text>
          </View>
        ) : null}
        {bannerVisible && (!googleKeyAvailable || settings.mapMode !== 'google') ? (
          <View style={styles.mapBanner}>
            <Feather name="info" size={14} color="#056b76" />
            <Text style={styles.mapBannerText}>Free map mode is active. Add a Google key in Settings for Google search and routing.</Text>
            <Pressable onPress={() => setBannerVisible(false)} accessibilityLabel="Dismiss free map notice">
              <Feather name="x" size={16} color="#056b76" />
            </Pressable>
          </View>
        ) : null}
        <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
          <Feather name="search" size={18} color={colors.mutedForeground} />
          <TextInput
            testID="place-search"
            accessibilityLabel="Search for a place"
            value={searchText}
            onChangeText={setSearchText}
            placeholder="Search a place or address"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="search"
            style={[styles.searchInput, { color: colors.foreground }]}
          />
          {searching ? <Text style={{ color: colors.primary, fontSize: 11 }}>Searching</Text> : null}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Use my location"
            onPress={() => void useLocation()}
            style={styles.locationButton}
          >
            <Feather name="crosshair" size={18} color={colors.primary} />
          </Pressable>
        </View>
        {searchResults.length > 0 ? (
          <View style={[styles.searchResults, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {searchResults.map((result, index) => (
              <Pressable
                key={`${result.latitude}-${result.longitude}-${index}`}
                accessibilityRole="button"
                onPress={() => selectResult(result)}
                style={[
                  styles.searchResult,
                  index < searchResults.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth },
                ]}
              >
                <View style={[styles.resultIcon, { backgroundColor: colors.accent }]}>
                  <Feather name="map-pin" size={15} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={[styles.resultName, { color: colors.foreground }]}>{result.name}</Text>
                  <Text numberOfLines={1} style={[styles.resultAddress, { color: colors.mutedForeground }]}>{result.address}</Text>
                </View>
              </Pressable>
            ))}
          </View>
        ) : null}
      </View>
      <View style={[styles.mapTools, { top: insets.top + (bannerVisible ? 184 : 130) }]}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Zoom in"
          onPress={() => setMapZoom((value) => Math.min(18, value + 1))}
          style={[styles.zoomButton, { backgroundColor: colors.card }]}
        >
          <Feather name="plus" size={19} color={colors.foreground} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Zoom out"
          onPress={() => setMapZoom((value) => Math.max(11, value - 1))}
          style={[styles.zoomButton, { backgroundColor: colors.card }]}
        >
          <Feather name="minus" size={19} color={colors.foreground} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Open route planner"
          onPress={() => router.push('/routes')}
          style={[styles.routeFab, { backgroundColor: colors.primary }]}
        >
          <Feather name="navigation" size={20} color="#ffffff" />
        </Pressable>
      </View>
      <ScrollView
        style={[styles.bottomSheet, { backgroundColor: colors.background }]}
        contentContainerStyle={{ paddingBottom: Math.max(insets.bottom, 10) + 74 }}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled
      >
        <View style={styles.sheetHandle} />
        <View style={styles.locationTitleRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.placeTitle, { color: colors.foreground }]} numberOfLines={1}>{selected.name}</Text>
            <Text style={[styles.placeSubtitle, { color: colors.mutedForeground }]}>
              {riskQuery.isLoading ? 'Checking local conditions…' : risk ? `Updated just now · ${risk.model_version}` : 'Risk check unavailable'}
            </Text>
          </View>
          <IconButton icon="bookmark" label="Save this place" color={colors.primary} onPress={saveCurrentPlace} />
          <IconButton icon="share-2" label="Share risk estimate" onPress={() => void shareRisk()} />
        </View>
        {riskQuery.isError ? (
          <View style={styles.errorLine}>
            <Feather name="alert-circle" size={16} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              {riskQuery.error instanceof Error ? riskQuery.error.message : 'Could not load the prediction.'}
            </Text>
            <Pressable onPress={() => void riskQuery.refetch()} accessibilityRole="button">
              <Text style={[styles.retryText, { color: colors.primary }]}>Retry</Text>
            </Pressable>
          </View>
        ) : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Open full water risk details"
          onPress={() => setDetailsVisible(true)}
          style={styles.riskSummary}
        >
          {risk ? (
            <RiskGauge probability={risk.probability} riskLevel={risk.risk_level} color={RISK_COLORS[risk.risk_level]} />
          ) : (
            <View style={[styles.gaugePlaceholder, { borderColor: colors.border }]} />
          )}
          <View style={styles.summaryDetails}>
            <RiskBadge level={riskLevel} />
            <Text style={[styles.confidenceText, { color: colors.foreground }]}>
              {risk ? `${Math.round(risk.confidence * 100)}% model confidence` : 'Calculating confidence'}
            </Text>
            <Text style={[styles.summaryCopy, { color: colors.mutedForeground }]}>
              {risk
                ? 'A simulated estimate from rain, terrain and placeholder drainage data.'
                : 'This prediction may need a network connection.'}
            </Text>
          </View>
        </Pressable>
        {risk && risk.factors.length > 0 ? (
          <View style={styles.factorStrip}>
            {risk.factors.slice(0, 2).map((factor) => (
              <View key={factor.name} style={[styles.factorChip, { backgroundColor: colors.secondary }]}>
                <View style={[styles.factorDot, { backgroundColor: RISK_COLORS[riskLevelForProbability(factor.impact)] }]} />
                <Text style={[styles.factorText, { color: colors.secondaryForeground }]}>{factor.name}</Text>
              </View>
            ))}
          </View>
        ) : null}
        <View style={[styles.whatIfBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.whatIfHeader}>
            <View>
              <Text style={[styles.whatIfTitle, { color: colors.foreground }]}>What-if rain simulator</Text>
              <Text style={[styles.whatIfSub, { color: colors.mutedForeground }]}>Adjust rain to explore a scenario</Text>
            </View>
            <Pressable
              accessibilityRole="button"
              onPress={() => { setRainfall(null); setRainDuration(null); }}
              style={{ padding: 8 }}
            >
              <Text style={{ color: colors.primary, fontFamily: 'Inter_600SemiBold', fontSize: 11 }}>Reset</Text>
            </Pressable>
          </View>
          <SliderControl
            label="Rain intensity"
            value={rainfall ?? riskQuery.data?.input.rainfall_intensity ?? 2}
            unit="mm/h"
            min={0}
            max={30}
            step={1}
            onChange={setRainfall}
          />
          <SliderControl
            label="Duration"
            value={rainDuration ?? riskQuery.data?.input.rainfall_duration ?? 1}
            unit="hours"
            min={0}
            max={12}
            step={1}
            onChange={setRainDuration}
          />
        </View>
        <View style={styles.quickActions}>
          <ActionButton
            label="Plan a safer route"
            icon="navigation"
            compact
            onPress={() => router.push('/routes')}
            style={{ flex: 1 }}
          />
          <ActionButton
            label="Report water"
            icon="alert-triangle"
            compact
            secondary
            onPress={() => setReportVisible(true)}
            style={{ flex: 1 }}
          />
        </View>
      </ScrollView>
      {useOnboarding(showWelcome, completeWelcome, colors)}
      <PhotoReportModal
        visible={reportVisible}
        point={selected}
        onClose={() => setReportVisible(false)}
      />
      <RiskDetailsModal
        visible={detailsVisible}
        point={selected}
        result={risk}
        onClose={() => setDetailsVisible(false)}
        onShare={() => void shareRisk()}
        onReport={() => {
          setDetailsVisible(false);
          setReportVisible(true);
        }}
      />
    </View>
  );
}

function SliderControl({
  label,
  value,
  unit,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  const colors = useAppColors();
  const fraction = Math.max(0, Math.min(1, (value - min) / (max - min)));
  return (
    <View style={styles.sliderRow}>
      <View style={styles.sliderTopRow}>
        <Text style={[styles.sliderLabel, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.sliderValue, { color: colors.primary }]}>{value} {unit}</Text>
      </View>
      <View style={styles.sliderControl}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Decrease ${label.toLowerCase()}`}
          onPress={() => onChange(Math.max(min, value - step))}
          style={styles.sliderStep}
        >
          <Feather name="minus" size={15} color={colors.mutedForeground} />
        </Pressable>
        <Pressable
          accessibilityRole="adjustable"
          accessibilityLabel={`${label}, ${value} ${unit}`}
          accessibilityValue={{ min, max, now: value }}
          onPress={(event) => {
            const width = event.nativeEvent.locationX;
            const parentWidth = 190;
            const raw = min + Math.max(0, Math.min(1, width / parentWidth)) * (max - min);
            onChange(Math.round(raw / step) * step);
          }}
          style={[styles.sliderTrack, { backgroundColor: colors.muted }]}
        >
          <View style={[styles.sliderFill, { width: `${fraction * 100}%`, backgroundColor: colors.primary }]} />
          <View style={[styles.sliderThumb, { left: `${fraction * 100}%`, borderColor: colors.primary, backgroundColor: colors.card }]} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Increase ${label.toLowerCase()}`}
          onPress={() => onChange(Math.min(max, value + step))}
          style={styles.sliderStep}
        >
          <Feather name="plus" size={15} color={colors.mutedForeground} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  offlineBanner: { minHeight: 34, borderRadius: 12, backgroundColor: '#31515d', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7, paddingHorizontal: 10 },
  offlineText: { color: '#ffffff', fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  topOverlay: { position: 'absolute', left: 14, right: 14, zIndex: 20, gap: 9 },
  brandRow: {
    height: 54,
    alignItems: 'center',
    flexDirection: 'row',
    gap: 9,
    paddingHorizontal: 11,
    borderRadius: 19,
    backgroundColor: '#ffffffed',
    shadowColor: '#032c38',
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 5,
  },
  brandMark: {
    width: 35,
    height: 35,
    borderRadius: 12,
    backgroundColor: '#0369a1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandName: { color: '#0e3442', fontFamily: 'Inter_700Bold', fontSize: 16, letterSpacing: -0.3 },
  brandMeta: { color: '#6b858e', fontFamily: 'Inter_500Medium', fontSize: 9, marginTop: 2 },
  floatIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#edf5f7' },
  mapBanner: {
    minHeight: 39,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 13,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    backgroundColor: '#e6f7f5',
    borderColor: '#b9e8e0',
    borderWidth: 1,
  },
  mapBannerText: { flex: 1, color: '#165e63', fontFamily: 'Inter_500Medium', fontSize: 10, lineHeight: 14 },
  searchBox: {
    height: 54,
    borderRadius: 17,
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: '#e3edf0',
    shadowColor: '#07313e',
    shadowOpacity: 0.1,
    shadowRadius: 14,
    elevation: 4,
  },
  searchInput: { flex: 1, height: '100%', fontFamily: 'Inter_500Medium', fontSize: 13 },
  locationButton: { width: 38, height: 40, justifyContent: 'center', alignItems: 'center' },
  searchResults: { borderRadius: 17, borderWidth: 1, overflow: 'hidden', shadowColor: '#07313e', shadowOpacity: 0.1, shadowRadius: 14, elevation: 5 },
  searchResult: { minHeight: 57, flexDirection: 'row', gap: 11, alignItems: 'center', paddingHorizontal: 12 },
  resultIcon: { width: 31, height: 31, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  resultName: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  resultAddress: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 2 },
  mapTools: { position: 'absolute', right: 15, zIndex: 9, gap: 10 },
  zoomButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center', elevation: 4 },
  routeFab: { width: 50, height: 50, borderRadius: 18, alignItems: 'center', justifyContent: 'center', elevation: 5 },
  bottomSheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 19,
    paddingTop: 10,
    maxHeight: '66%',
    shadowColor: '#082d38',
    shadowOpacity: 0.14,
    shadowRadius: 25,
    elevation: 14,
  },
  sheetHandle: { alignSelf: 'center', width: 38, height: 4, borderRadius: 3, backgroundColor: '#b6c7cd', marginBottom: 13 },
  locationTitleRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 7 },
  placeTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: -0.35 },
  placeSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  riskSummary: { flexDirection: 'row', alignItems: 'center', gap: 18, paddingTop: 2, paddingBottom: 9 },
  gaugePlaceholder: { width: 112, height: 112, borderWidth: 9, borderRadius: 56 },
  detailsScreen: { flex: 1, paddingHorizontal: 18, paddingTop: 8 },
  detailsHeader: { minHeight: 63, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  detailsEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 1.2 },
  detailsTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, marginTop: 3 },
  detailsGaugeWrap: { alignItems: 'center', gap: 9, paddingVertical: 21 },
  detailsConfidence: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  detailsCard: { marginBottom: 12 },
  detailsSectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 13, marginBottom: 13 },
  factorRow: { marginBottom: 12 },
  factorLabelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  detailsFactorName: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  detailsFactorValue: { fontFamily: 'Inter_600SemiBold', fontSize: 9 },
  detailsTrack: { height: 7, borderRadius: 6, overflow: 'hidden' },
  detailsFill: { height: 7, borderRadius: 6 },
  forecastRow: { flexDirection: 'row', gap: 7 },
  forecastItem: { flex: 1, borderRadius: 12, alignItems: 'center', paddingVertical: 10 },
  forecastTime: { fontFamily: 'Inter_500Medium', fontSize: 8 },
  forecastPercent: { fontFamily: 'Inter_700Bold', fontSize: 15, marginTop: 4 },
  detailsEmpty: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 16 },
  detailsFootnote: { fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 14, marginHorizontal: 4, marginBottom: 11 },
  detailsActions: { flexDirection: 'row', gap: 8, marginTop: 7 },
  summaryDetails: { flex: 1, gap: 8 },
  confidenceText: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  summaryCopy: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  factorStrip: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginBottom: 9 },
  factorChip: { borderRadius: 99, minHeight: 27, flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 9 },
  factorDot: { width: 6, height: 6, borderRadius: 3 },
  factorText: { fontFamily: 'Inter_500Medium', fontSize: 9 },
  whatIfBox: { borderRadius: 17, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10 },
  whatIfHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 },
  whatIfTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  whatIfSub: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 2 },
  sliderRow: { marginTop: 6 },
  sliderTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sliderLabel: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  sliderValue: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  sliderControl: { flexDirection: 'row', alignItems: 'center', gap: 6, height: 30 },
  sliderStep: { width: 26, alignItems: 'center', justifyContent: 'center', height: 30 },
  sliderTrack: { flex: 1, height: 5, borderRadius: 5, justifyContent: 'center' },
  sliderFill: { height: 5, borderRadius: 5 },
  sliderThumb: { width: 15, height: 15, borderRadius: 8, borderWidth: 2, position: 'absolute', marginLeft: -7.5, elevation: 1 },
  quickActions: { flexDirection: 'row', gap: 9, marginTop: 9 },
  errorLine: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 6 },
  errorText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 10 },
  retryText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  onboardingBackdrop: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#062f3acc' },
  onboardingCard: { borderRadius: 28, padding: 24 },
  onboardingIcon: { width: 58, height: 58, borderRadius: 19, alignItems: 'center', justifyContent: 'center', marginBottom: 22 },
  onboardingTitle: { fontFamily: 'Inter_700Bold', fontSize: 24, lineHeight: 31, letterSpacing: -0.5 },
  onboardingBody: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginTop: 10, marginBottom: 23 },
  onboardingDots: { flexDirection: 'row', gap: 6, justifyContent: 'center', marginBottom: 20 },
  onboardingDot: { height: 5, width: 18, borderRadius: 4 },
  modalBackdrop: { flex: 1, backgroundColor: '#001b22aa', justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, paddingBottom: 24 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 },
  modalTitle: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  modalSub: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 3 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginBottom: 8 },
  severityRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  severityChoice: { flex: 1, height: 42, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  reportInput: { minHeight: 86, borderWidth: 1, borderRadius: 15, padding: 12, textAlignVertical: 'top', fontFamily: 'Inter_400Regular', fontSize: 13, marginBottom: 12 },
  reportPhoto: { width: 70, height: 70, borderRadius: 12, marginBottom: 10 },
  localNote: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 10 },
});
