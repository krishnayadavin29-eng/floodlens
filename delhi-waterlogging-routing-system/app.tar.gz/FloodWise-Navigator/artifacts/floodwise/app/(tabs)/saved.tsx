import React, { useState } from 'react';
import {
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppCard, IconButton, RiskBadge, ScreenTitle } from '@/src/components/ui';
import { useAppColors } from '@/src/hooks/useAppColors';
import { useFloodStore } from '@/src/store/appStore';
import type { SavedPlace } from '@/src/types/domain';

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recently';
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export default function SavedScreen() {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const savedPlaces = useFloodStore((state) => state.savedPlaces);
  const savedRoutes = useFloodStore((state) => state.savedRoutes);
  const recentChecks = useFloodStore((state) => state.recentChecks);
  const reports = useFloodStore((state) => state.reports);
  const units = useFloodStore((state) => state.settings.units);
  const savePlace = useFloodStore((state) => state.savePlace);
  const removePlace = useFloodStore((state) => state.removePlace);
  const removeRoute = useFloodStore((state) => state.removeRoute);
  const [segment, setSegment] = useState<'places' | 'routes' | 'history'>('places');

  function updateCategory(place: SavedPlace, category: SavedPlace['category']) {
    savePlace({ ...place, category });
    Alert.alert('Saved place updated', `${place.name} is now marked as ${category}.`);
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + 20, paddingBottom: Math.max(insets.bottom, 14) + 90 },
        ]}
      >
        <ScreenTitle
          title="Saved"
          subtitle="Keep important places and route checks close."
          action={
            <View style={[styles.titleIcon, { backgroundColor: colors.accent }]}>
              <Feather name="bookmark" size={20} color={colors.primary} />
            </View>
          }
        />
        <View style={[styles.segmentControl, { backgroundColor: colors.secondary }]}>
          {([
            ['places', 'Places'],
            ['routes', 'Routes'],
            ['history', 'History'],
          ] as const).map(([value, label]) => (
            <Pressable
              key={value}
              accessibilityRole="tab"
              accessibilityState={{ selected: segment === value }}
              onPress={() => setSegment(value)}
              style={[
                styles.segment,
                { backgroundColor: segment === value ? colors.card : 'transparent' },
              ]}
            >
              <Text style={[styles.segmentText, { color: segment === value ? colors.foreground : colors.mutedForeground }]}>
                {label}
              </Text>
            </Pressable>
          ))}
        </View>

        {segment === 'places' ? (
          savedPlaces.length ? (
            <View style={styles.list}>
              {savedPlaces.map((place) => (
                <AppCard key={place.id} style={styles.savedCard}>
                  <Pressable
                    accessibilityRole="button"
                    onPress={() =>
                      router.push({
                        pathname: '/',
                        params: {
                          lat: place.latitude,
                          lon: place.longitude,
                          label: place.name,
                        },
                      })
                    }
                    style={styles.cardMain}
                  >
                    <View style={[styles.placeIcon, { backgroundColor: colors.accent }]}>
                      <Feather
                        name={place.category === 'home' ? 'home' : place.category === 'work' ? 'briefcase' : 'map-pin'}
                        size={17}
                        color={colors.primary}
                      />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.itemTitle, { color: colors.foreground }]} numberOfLines={1}>{place.name}</Text>
                      <Text style={[styles.itemSubtitle, { color: colors.mutedForeground }]}>
                        {place.category === 'custom' ? 'custom place' : place.category} · saved {formatDate(place.addedAt)}
                      </Text>
                    </View>
                    <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                  </Pressable>
                  <View style={[styles.cardActions, { borderTopColor: colors.border }]}>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => updateCategory(place, 'home')}
                      style={[styles.categoryButton, place.category === 'home' && { backgroundColor: colors.accent }]}
                    >
                      <Feather name="home" size={12} color={colors.accentForeground} />
                      <Text style={[styles.categoryText, { color: colors.accentForeground }]}>Home</Text>
                    </Pressable>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => updateCategory(place, 'work')}
                      style={[styles.categoryButton, place.category === 'work' && { backgroundColor: colors.accent }]}
                    >
                      <Feather name="briefcase" size={12} color={colors.accentForeground} />
                      <Text style={[styles.categoryText, { color: colors.accentForeground }]}>Work</Text>
                    </Pressable>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => updateCategory(place, 'custom')}
                      style={[styles.categoryButton, place.category === 'custom' && { backgroundColor: colors.accent }]}
                    >
                      <Feather name="map-pin" size={12} color={colors.accentForeground} />
                      <Text style={[styles.categoryText, { color: colors.accentForeground }]}>Custom</Text>
                    </Pressable>
                    <IconButton
                      icon="trash-2"
                      label={`Remove ${place.name}`}
                      color={colors.destructive}
                      style={styles.deleteButton}
                      onPress={() =>
                        Alert.alert('Remove saved place?', place.name, [
                          { text: 'Keep', style: 'cancel' },
                          { text: 'Remove', style: 'destructive', onPress: () => removePlace(place.id) },
                        ])
                      }
                    />
                  </View>
                </AppCard>
              ))}
            </View>
          ) : (
            <EmptyState
              icon="map-pin"
              title="No saved places yet"
              body="Save a place from the map to keep an eye on it."
              action="Open the map"
              onPress={() => router.push('/')}
            />
          )
        ) : null}

        {segment === 'routes' ? (
          savedRoutes.length ? (
            <View style={styles.list}>
              {savedRoutes.map((route) => (
                <AppCard key={route.id} style={styles.savedCard}>
                  <Pressable
                    accessibilityRole="button"
                    onPress={() =>
                      router.push({
                        pathname: '/routes',
                        params: { origin: route.origin, destination: route.destination },
                      })
                    }
                    style={styles.cardMain}
                  >
                    <View style={[styles.placeIcon, { backgroundColor: colors.secondary }]}>
                      <Feather name="navigation" size={17} color={colors.secondaryForeground} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.itemTitle, { color: colors.foreground }]} numberOfLines={1}>{route.origin} → {route.destination}</Text>
                      <Text style={[styles.itemSubtitle, { color: colors.mutedForeground }]}>
                        {route.mode} · {units === 'mi'
                          ? `${(route.distanceMeters / 1609.344).toFixed(1)} mi`
                          : `${(route.distanceMeters / 1000).toFixed(1)} km`} · {Math.round(route.durationSeconds / 60)} min
                      </Text>
                    </View>
                    <IconButton
                      icon="trash-2"
                      label="Remove saved route"
                      color={colors.destructive}
                      onPress={() => removeRoute(route.id)}
                    />
                  </Pressable>
                </AppCard>
              ))}
            </View>
          ) : (
            <EmptyState
              icon="navigation"
              title="No saved routes"
              body="Compare routes, then save the option you want to revisit."
              action="Plan a route"
              onPress={() => router.push('/routes')}
            />
          )
        ) : null}

        {segment === 'history' ? (
          <View style={styles.list}>
            {recentChecks.length === 0 && reports.length === 0 ? (
              <EmptyState
                icon="clock"
                title="Your activity will appear here"
                body="Recent checks and community reports stay on this device."
                action="Check a place"
                onPress={() => router.push('/')}
              />
            ) : null}
            {recentChecks.map((check) => (
              <Pressable
                key={check.id}
                accessibilityRole="button"
                onPress={() =>
                  router.push({
                    pathname: '/',
                    params: { lat: check.latitude, lon: check.longitude, label: check.name },
                  })
                }
                style={[styles.historyRow, { backgroundColor: colors.card, borderColor: colors.border }]}
              >
                <View style={[styles.historyIcon, { backgroundColor: `${riskColor(check.riskLevel)}20` }]}>
                  <Feather name="activity" size={15} color={riskColor(check.riskLevel)} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={[styles.itemTitle, { color: colors.foreground }]}>{check.name}</Text>
                  <Text style={[styles.itemSubtitle, { color: colors.mutedForeground }]}>{formatDate(check.checkedAt)}</Text>
                </View>
                <View style={styles.historyRisk}>
                  <Text style={[styles.historyPercent, { color: riskColor(check.riskLevel) }]}>{Math.round(check.probability * 100)}%</Text>
                  <RiskBadge level={check.riskLevel} />
                </View>
              </Pressable>
            ))}
            {reports.map((report) => (
              <AppCard key={report.id} style={styles.reportCard}>
                <View style={styles.historyRowInner}>
                  <View style={[styles.historyIcon, { backgroundColor: `${riskColor(report.severity)}20` }]}>
                    <Feather name="alert-triangle" size={15} color={riskColor(report.severity)} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.itemTitle, { color: colors.foreground }]}>Community water report</Text>
                    <Text style={[styles.itemSubtitle, { color: colors.mutedForeground }]}>{formatDate(report.createdAt)} · stored on this device</Text>
                  </View>
                  <RiskBadge level={report.severity} />
                </View>
                {report.description ? <Text style={[styles.reportDescription, { color: colors.mutedForeground }]}>{report.description}</Text> : null}
                {report.photoUri ? <Image source={{ uri: report.photoUri }} style={styles.reportThumb} /> : null}
              </AppCard>
            ))}
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

function riskColor(level: 'low' | 'moderate' | 'high' | 'severe') {
  return { low: '#22C55E', moderate: '#E6B921', high: '#F97316', severe: '#EF4444' }[level];
}

function EmptyState({
  icon,
  title,
  body,
  action,
  onPress,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  title: string;
  body: string;
  action: string;
  onPress: () => void;
}) {
  const colors = useAppColors();
  return (
    <AppCard style={styles.emptyCard}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
        <Feather name={icon} size={21} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>{body}</Text>
      <Pressable accessibilityRole="button" onPress={onPress} style={[styles.emptyAction, { backgroundColor: colors.secondary }]}>
        <Text style={[styles.emptyActionText, { color: colors.secondaryForeground }]}>{action}</Text>
        <Feather name="arrow-right" size={13} color={colors.secondaryForeground} />
      </Pressable>
    </AppCard>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18 },
  titleIcon: { width: 47, height: 47, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  segmentControl: { padding: 4, flexDirection: 'row', borderRadius: 15, marginBottom: 16 },
  segment: { height: 36, flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 11 },
  segmentText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  list: { gap: 10 },
  savedCard: { padding: 0, overflow: 'hidden' },
  cardMain: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 14, minHeight: 72 },
  placeIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  itemTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  itemSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 4 },
  cardActions: { borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 3, gap: 5 },
  categoryButton: { minHeight: 33, borderRadius: 10, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 5 },
  categoryText: { fontFamily: 'Inter_600SemiBold', fontSize: 9 },
  deleteButton: { marginLeft: 'auto' },
  historyRow: { minHeight: 67, borderRadius: 18, borderWidth: 1, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  historyRowInner: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  historyIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  historyRisk: { alignItems: 'flex-end', gap: 4 },
  historyPercent: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  reportCard: { padding: 13 },
  reportDescription: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 10 },
  reportThumb: { width: 65, height: 65, borderRadius: 12, marginTop: 9 },
  emptyCard: { alignItems: 'center', padding: 24, marginTop: 3 },
  emptyIcon: { width: 53, height: 53, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 13 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  emptyBody: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 6, maxWidth: 250 },
  emptyAction: { flexDirection: 'row', alignItems: 'center', gap: 7, borderRadius: 12, minHeight: 39, paddingHorizontal: 13, marginTop: 16 },
  emptyActionText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
});
