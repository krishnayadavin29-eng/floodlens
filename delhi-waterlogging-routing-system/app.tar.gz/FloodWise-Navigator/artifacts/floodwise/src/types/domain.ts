export type RiskLevel = 'low' | 'moderate' | 'high' | 'severe';
export type PredictionMode = 'mock' | 'remote' | 'ondevice';
export type MapMode = 'free' | 'google';
export type ThemeMode = 'system' | 'light' | 'dark';
export type TravelMode = 'driving' | 'cycling' | 'walking';

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface SavedPlace extends Coordinates {
  id: string;
  name: string;
  category: 'home' | 'work' | 'custom';
  addedAt: string;
}

export interface SavedRoute {
  id: string;
  origin: string;
  destination: string;
  mode: TravelMode;
  distanceMeters: number;
  durationSeconds: number;
  savedAt: string;
}

export interface RecentCheck extends Coordinates {
  id: string;
  name: string;
  probability: number;
  riskLevel: RiskLevel;
  checkedAt: string;
}

export interface CommunityReport extends Coordinates {
  id: string;
  severity: RiskLevel;
  description: string;
  photoUri?: string;
  createdAt: string;
}

export interface AppSettings {
  theme: ThemeMode;
  units: 'km' | 'mi';
  riskThreshold: RiskLevel;
  alertsEnabled: boolean;
  quietHoursEnabled: boolean;
  weatherAutoFetch: boolean;
  predictionMode: PredictionMode;
  mapMode: MapMode;
  predictionApiUrl: string;
}

export interface PlaceSearchResult extends Coordinates {
  name: string;
  address: string;
}
