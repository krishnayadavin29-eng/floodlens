export const DEFAULT_MAP_CENTER = { latitude: 22.5726, longitude: 88.3639 };
export const MAP_ZOOM = 14;
export const RISK_THRESHOLDS = {
  low: 0.25,
  moderate: 0.5,
  high: 0.75,
} as const;
export const ROUTE_RECOMMENDATION_EXTRA_TIME = 0.25;
export const MAX_ROUTE_SAMPLES = 60;
export const ROUTE_SAMPLE_METERS = 200;
export const WEATHER_CACHE_MS = 10 * 60 * 1000;
export const SEARCH_CACHE_MS = 30 * 60 * 1000;

export const RISK_COLORS = {
  low: '#22C55E',
  moderate: '#E6B921',
  high: '#F97316',
  severe: '#EF4444',
} as const;

export function riskLevelForProbability(probability: number) {
  if (probability < RISK_THRESHOLDS.low) return 'low' as const;
  if (probability < RISK_THRESHOLDS.moderate) return 'moderate' as const;
  if (probability < RISK_THRESHOLDS.high) return 'high' as const;
  return 'severe' as const;
}
