import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type {
  AppSettings,
  CommunityReport,
  RecentCheck,
  SavedPlace,
  SavedRoute,
} from '@/src/types/domain';

interface FloodWiseState {
  settings: AppSettings;
  savedPlaces: SavedPlace[];
  savedRoutes: SavedRoute[];
  recentChecks: RecentCheck[];
  reports: CommunityReport[];
  onboardingComplete: boolean;
  lastAlertedAt: string | null;
  updateSettings: (patch: Partial<AppSettings>) => void;
  savePlace: (place: SavedPlace) => void;
  removePlace: (id: string) => void;
  saveRoute: (route: SavedRoute) => void;
  removeRoute: (id: string) => void;
  addCheck: (check: RecentCheck) => void;
  addReport: (report: CommunityReport) => void;
  finishOnboarding: () => void;
  setLastAlertedAt: (value: string) => void;
}

export const defaultSettings: AppSettings = {
  theme: 'system',
  units: 'km',
  riskThreshold: 'high',
  alertsEnabled: false,
  quietHoursEnabled: true,
  weatherAutoFetch: true,
  predictionMode: 'mock',
  mapMode: 'free',
  predictionApiUrl: process.env.EXPO_PUBLIC_PREDICTION_API_URL ?? '',
};

export const useFloodStore = create<FloodWiseState>()(
  persist(
    (set, get) => ({
      settings: defaultSettings,
      savedPlaces: [],
      savedRoutes: [],
      recentChecks: [],
      reports: [],
      onboardingComplete: false,
      lastAlertedAt: null,
      updateSettings: (patch) =>
        set((state) => ({ settings: { ...state.settings, ...patch } })),
      savePlace: (place) =>
        set((state) => ({
          savedPlaces: [
            place,
            ...state.savedPlaces.filter(
              (item) =>
                item.id !== place.id &&
                !(item.latitude === place.latitude &&
                  item.longitude === place.longitude),
            ),
          ],
        })),
      removePlace: (id) =>
        set((state) => ({
          savedPlaces: state.savedPlaces.filter((item) => item.id !== id),
        })),
      saveRoute: (route) =>
        set((state) => ({
          savedRoutes: [
            route,
            ...state.savedRoutes.filter((item) => item.id !== route.id),
          ],
        })),
      removeRoute: (id) =>
        set((state) => ({
          savedRoutes: state.savedRoutes.filter((item) => item.id !== id),
        })),
      addCheck: (check) =>
        set((state) => ({
          recentChecks: [check, ...state.recentChecks].slice(0, 30),
        })),
      addReport: (report) =>
        set((state) => ({ reports: [report, ...state.reports] })),
      finishOnboarding: () => set({ onboardingComplete: true }),
      setLastAlertedAt: (value) => set({ lastAlertedAt: value }),
    }),
    {
      name: 'floodwise-local-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        settings: state.settings,
        savedPlaces: state.savedPlaces,
        savedRoutes: state.savedRoutes,
        recentChecks: state.recentChecks,
        reports: state.reports,
        onboardingComplete: state.onboardingComplete,
        lastAlertedAt: state.lastAlertedAt,
      }),
    },
  ),
);

export function resetFloodWiseSettings() {
  getDefaultSettings();
}

function getDefaultSettings() {
  useFloodStore.getState().updateSettings(defaultSettings);
}
