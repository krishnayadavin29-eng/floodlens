import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
  type PressableProps,
  type ViewProps,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useAppColors } from '@/src/hooks/useAppColors';

export function AppCard({ style, ...props }: ViewProps) {
  const colors = useAppColors();
  return (
    <View
      {...props}
      style={[
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border },
        style,
      ]}
    />
  );
}

export function Eyebrow({ children }: { children: React.ReactNode }) {
  const colors = useAppColors();
  return (
    <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
      {children}
    </Text>
  );
}

export function ActionButton({
  label,
  icon,
  onPress,
  secondary = false,
  loading = false,
  disabled = false,
  compact = false,
  accessibilityLabel,
  style,
  ...props
}: Omit<PressableProps, 'children'> & {
  label: string;
  icon?: React.ComponentProps<typeof Feather>['name'];
  secondary?: boolean;
  loading?: boolean;
  compact?: boolean;
}) {
  const colors = useAppColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? label}
      disabled={disabled || loading}
      onPress={onPress}
      style={({ pressed }) => {
        const extraStyle =
          typeof style === 'function'
            ? style({ pressed, hovered: false })
            : style;
        return [
          styles.button,
          compact && styles.compactButton,
          {
            backgroundColor: secondary ? colors.secondary : colors.primary,
            opacity: disabled ? 0.48 : pressed ? 0.82 : 1,
          },
          extraStyle,
        ];
      }}
      {...props}
    >
      {loading ? (
        <ActivityIndicator color={secondary ? colors.secondaryForeground : colors.primaryForeground} />
      ) : (
        <>
          {icon ? (
            <Feather
              name={icon}
              size={compact ? 16 : 18}
              color={secondary ? colors.secondaryForeground : colors.primaryForeground}
            />
          ) : null}
          <Text
            style={[
              styles.buttonText,
              { color: secondary ? colors.secondaryForeground : colors.primaryForeground },
            ]}
          >
            {label}
          </Text>
        </>
      )}
    </Pressable>
  );
}

export function IconButton({
  icon,
  onPress,
  label,
  color,
  style,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  onPress: () => void;
  label: string;
  color?: string;
  style?: object;
}) {
  const colors = useAppColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.55 : 1 }, style]}
    >
      <Feather name={icon} size={19} color={color ?? colors.foreground} />
    </Pressable>
  );
}

export function RiskBadge({ level }: { level: 'low' | 'moderate' | 'high' | 'severe' }) {
  const colors = useAppColors();
  const swatches = {
    low: '#22C55E',
    moderate: '#E6B921',
    high: '#F97316',
    severe: '#EF4444',
  };
  const labels = { low: 'Low', moderate: 'Moderate', high: 'High', severe: 'Severe' };
  return (
    <View style={[styles.badge, { backgroundColor: `${swatches[level]}20` }]}>
      <View style={[styles.badgeDot, { backgroundColor: swatches[level] }]} />
      <Text style={[styles.badgeText, { color: colors.foreground }]}>
        {labels[level]}
      </Text>
    </View>
  );
}

export function ScreenTitle({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.titleRow}>
      <View style={{ flex: 1 }}>
        <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
        {subtitle ? (
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {action}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: 22,
    padding: 17,
    shadowColor: '#083746',
    shadowOpacity: 0.055,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 7 },
    elevation: 2,
  },
  eyebrow: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 10,
    letterSpacing: 1.15,
    textTransform: 'uppercase',
  },
  button: {
    minHeight: 50,
    borderRadius: 16,
    paddingHorizontal: 17,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 9,
  },
  compactButton: {
    minHeight: 40,
    borderRadius: 13,
    paddingHorizontal: 13,
  },
  buttonText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  iconButton: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 99,
    gap: 6,
  },
  badgeDot: { width: 7, height: 7, borderRadius: 4 },
  badgeText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 22,
    gap: 12,
  },
  title: { fontFamily: 'Inter_700Bold', fontSize: 28, letterSpacing: -0.6 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 4, lineHeight: 19 },
});
