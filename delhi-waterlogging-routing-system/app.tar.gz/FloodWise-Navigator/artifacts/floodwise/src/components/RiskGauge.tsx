import React, { useEffect } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import Animated, {
  Easing,
  useAnimatedProps,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { RISK_COLORS } from '@/src/config/constants';
import type { RiskLevel } from '@/src/types/domain';

const SIZE = 112;
const STROKE = 10;
const AnimatedCircle = Animated.createAnimatedComponent(Circle);
const labels: Record<RiskLevel, string> = {
  low: 'Low',
  moderate: 'Moderate',
  high: 'High',
  severe: 'Severe',
};

export function RiskGauge({
  probability,
  riskLevel,
  color,
  size = SIZE,
}: {
  probability: number;
  riskLevel: RiskLevel;
  color: string;
  size?: number;
}) {
  const stroke = 10;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = useSharedValue(0);
  const animatedProps = useAnimatedProps(() => ({
    strokeDashoffset: circumference * (1 - progress.value),
  }));

  useEffect(() => {
    progress.value = withTiming(Math.max(0, Math.min(1, probability)), {
      duration: 720,
      easing: Easing.out(Easing.cubic),
    });
  }, [probability, progress]);

  return (
    <View
      accessible
      accessibilityRole="image"
      accessibilityLabel={`${Math.round(probability * 100)} percent waterlogging risk, ${labels[riskLevel]}`}
      style={[styles.wrap, { width: size, height: size }]}
    >
      <Svg
        width={size}
        height={size}
        style={[
          StyleSheet.absoluteFill,
          Platform.OS === 'web' && { transform: [{ rotate: '-90deg' }] },
        ]}
      >
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#dce8ec"
          strokeWidth={stroke}
          fill="none"
        />
        {Platform.OS === 'web' ? (
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color || RISK_COLORS[riskLevel]}
            strokeWidth={stroke}
            strokeDasharray={`${circumference * Math.max(0, Math.min(1, probability))} ${circumference}`}
            strokeLinecap="round"
            fill="none"
          />
        ) : (
          <AnimatedCircle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color || RISK_COLORS[riskLevel]}
            strokeWidth={stroke}
            strokeDasharray={`${circumference} ${circumference}`}
            animatedProps={animatedProps}
            strokeLinecap="round"
            fill="none"
          />
        )}
      </Svg>
      <View style={styles.center}>
        <Text style={[styles.value, { color: color || RISK_COLORS[riskLevel] }]}>
          {Math.round(probability * 100)}%
        </Text>
        <Text style={styles.caption}>{labels[riskLevel]} risk</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center' },
  center: { alignItems: 'center', justifyContent: 'center' },
  value: { fontFamily: 'Inter_700Bold', fontSize: 25 },
  caption: { color: '#67808b', fontFamily: 'Inter_500Medium', fontSize: 11, marginTop: 1 },
});
