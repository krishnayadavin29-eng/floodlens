import React, { useMemo, useRef, useState } from 'react';
import {
  Image,
  PanResponder,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
  type LayoutChangeEvent,
} from 'react-native';
import { RISK_COLORS } from '@/src/config/constants';
import type { Coordinates, RiskLevel } from '@/src/types/domain';

type Marker = Coordinates & { probability: number; riskLevel: RiskLevel; label?: string };
const TILE_SIZE = 256;
function lonToX(longitude: number, zoom: number) {
  return ((longitude + 180) / 360) * 2 ** zoom;
}

function latToY(latitude: number, zoom: number) {
  const rad = (latitude * Math.PI) / 180;
  return ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * 2 ** zoom;
}

function xToLon(x: number, zoom: number) {
  return (x / 2 ** zoom) * 360 - 180;
}

function yToLat(y: number, zoom: number) {
  const n = Math.PI - (2 * Math.PI * y) / 2 ** zoom;
  return (180 / Math.PI) * Math.atan(Math.sinh(n));
}

function tileNumber(value: number) {
  return Math.floor(value);
}

export function MapCanvas({
  center,
  markers = [],
  showRisk = true,
  showMap = true,
  zoom,
  onMapPress,
  onMarkerPress,
  location,
}: {
  center: Coordinates;
  markers?: Marker[];
  showRisk?: boolean;
  showMap?: boolean;
  zoom: number;
  onMapPress: (point: Coordinates) => void;
  onMarkerPress: (marker: Marker) => void;
  location?: Coordinates | null;
}) {
  const dimensions = useWindowDimensions();
  const [size, setSize] = useState({ width: dimensions.width, height: dimensions.height });
  const [mapCenter, setMapCenter] = useState(center);
  const mapCenterRef = useRef(center);
  const dragOrigin = useRef({ x: 0, y: 0 });
  const centerX = lonToX(mapCenter.longitude, zoom);
  const centerY = latToY(mapCenter.latitude, zoom);
  const xCount = Math.ceil(size.width / TILE_SIZE) + 2;
  const yCount = Math.ceil(size.height / TILE_SIZE) + 2;
  const firstX = tileNumber(centerX) - Math.floor(xCount / 2);
  const firstY = tileNumber(centerY) - Math.floor(yCount / 2);
  const tiles = [];
  for (let row = 0; row < yCount; row += 1) {
    for (let column = 0; column < xCount; column += 1) {
      const x = firstX + column;
      const y = firstY + row;
      tiles.push({
        key: `${zoom}/${x}/${y}`,
        uri: `https://tile.openstreetmap.org/${zoom}/${x}/${y}.png`,
        left: (x - centerX) * TILE_SIZE + size.width / 2,
        top: (y - centerY) * TILE_SIZE + size.height / 2,
      });
    }
  }

  React.useEffect(() => {
    mapCenterRef.current = center;
    setMapCenter(center);
  }, [center.latitude, center.longitude]);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_event, gesture) =>
          Math.abs(gesture.dx) > 8 || Math.abs(gesture.dy) > 8,
        onPanResponderGrant: () => {
          dragOrigin.current = {
            x: lonToX(mapCenterRef.current.longitude, zoom),
            y: latToY(mapCenterRef.current.latitude, zoom),
          };
        },
        onPanResponderMove: (_event, gesture) => {
          const next = {
            longitude: xToLon(dragOrigin.current.x - gesture.dx / TILE_SIZE, zoom),
            latitude: yToLat(dragOrigin.current.y - gesture.dy / TILE_SIZE, zoom),
          };
          mapCenterRef.current = next;
          setMapCenter(next);
        },
      }),
    [zoom],
  );

  function handleLayout(event: LayoutChangeEvent) {
    const { width, height } = event.nativeEvent.layout;
    setSize({ width, height });
  }

  function pointToPosition(point: Coordinates) {
    return {
      left:
        (lonToX(point.longitude, zoom) - centerX) * TILE_SIZE +
        size.width / 2,
      top:
        (latToY(point.latitude, zoom) - centerY) * TILE_SIZE +
        size.height / 2,
    };
  }

  function pressMap(event: { nativeEvent: { locationX: number; locationY: number } }) {
    const { locationX, locationY } = event.nativeEvent;
    onMapPress({
      longitude: xToLon(
        centerX + (locationX - size.width / 2) / TILE_SIZE,
        zoom,
      ),
      latitude: yToLat(
        centerY + (locationY - size.height / 2) / TILE_SIZE,
        zoom,
      ),
    });
  }

  return (
    <View style={styles.root} onLayout={handleLayout} {...panResponder.panHandlers}>
      <View style={[StyleSheet.absoluteFill, { backgroundColor: '#dfedf0' }]} />
      {showMap
        ? tiles.map((tile) => (
            <Image
              key={tile.key}
              source={{ uri: tile.uri }}
              style={[
                styles.tile,
                { left: tile.left, top: tile.top },
              ]}
              resizeMode="stretch"
              accessibilityLabel="OpenStreetMap map tile"
            />
          ))
        : null}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Select a point on the map"
        style={StyleSheet.absoluteFill}
        onPress={pressMap}
      />
      {showRisk
        ? markers.map((marker) => {
            const position = pointToPosition(marker);
            return (
              <View
                key={`${marker.latitude}-${marker.longitude}`}
                style={[styles.markerWrap, { left: position.left - 20, top: position.top - 20 }]}
                pointerEvents="box-none"
              >
                <Pressable
                  accessibilityRole="button"
                  onPress={() => onMarkerPress(marker)}
                  style={({ pressed }) => [
                    styles.marker,
                    {
                      backgroundColor: RISK_COLORS[marker.riskLevel],
                      opacity: pressed ? 0.78 : 1,
                    },
                  ]}
                >
                  <Text style={styles.markerText}>{Math.round(marker.probability * 100)}%</Text>
                </Pressable>
              </View>
            );
          })
        : null}
      {location
        ? (() => {
            const position = pointToPosition(location);
            return (
              <View
                pointerEvents="none"
                style={[
                  styles.currentDot,
                  { left: position.left - 9, top: position.top - 9 },
                ]}
              >
                <View style={styles.currentDotCore} />
              </View>
            );
          })()
        : null}
      <View style={styles.attribution} pointerEvents="none">
        <Text style={styles.attributionText}>© OpenStreetMap contributors</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, overflow: 'hidden', backgroundColor: '#dfedf0' },
  tile: { width: TILE_SIZE, height: TILE_SIZE, position: 'absolute' },
  markerWrap: { position: 'absolute', zIndex: 8 },
  marker: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#ffffff',
    minWidth: 42,
    elevation: 4,
  },
  markerText: { color: '#ffffff', fontFamily: 'Inter_700Bold', fontSize: 11, textAlign: 'center' },
  currentDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#2196f3',
    borderWidth: 3,
    borderColor: '#ffffff',
    position: 'absolute',
    zIndex: 10,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
  },
  currentDotCore: { width: 4, height: 4, borderRadius: 2, backgroundColor: '#ffffff' },
  attribution: {
    position: 'absolute',
    right: 7,
    bottom: 7,
    backgroundColor: '#ffffffd9',
    borderRadius: 5,
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  attributionText: { fontFamily: 'Inter_400Regular', fontSize: 8, color: '#354b55' },
});

