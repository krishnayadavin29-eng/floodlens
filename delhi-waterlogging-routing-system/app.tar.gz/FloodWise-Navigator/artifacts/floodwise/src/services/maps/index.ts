import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import type { AppSettings } from '@/src/types/domain';
import { GoogleMapProvider } from './GoogleMapProvider';
import { OpenSourceMapProvider } from './OpenSourceMapProvider';
import type { MapProvider } from './types';

const freeProvider = new OpenSourceMapProvider();

export async function getMapProvider(settings: AppSettings): Promise<MapProvider> {
  if (settings.mapMode !== 'google') return freeProvider;
  const key = await getGoogleMapsKey();
  return key ? new GoogleMapProvider(key) : freeProvider;
}

export async function getGoogleMapsKey() {
  if (Platform.OS === 'web') return null;
  return SecureStore.getItemAsync('floodwise-google-maps-key');
}

export async function saveGoogleMapsKey(value: string) {
  assertNativeSecureStorage();
  const normalized = value.trim();
  if (!normalized) {
    await SecureStore.deleteItemAsync('floodwise-google-maps-key');
    return;
  }
  await SecureStore.setItemAsync('floodwise-google-maps-key', normalized);
}

export async function savePredictionApiKey(value: string) {
  assertNativeSecureStorage();
  const normalized = value.trim();
  if (!normalized) {
    await SecureStore.deleteItemAsync('floodwise-prediction-api-key');
    return;
  }
  await SecureStore.setItemAsync('floodwise-prediction-api-key', normalized);
}

export async function getPredictionApiKey() {
  if (Platform.OS === 'web') return null;
  return SecureStore.getItemAsync('floodwise-prediction-api-key');
}

function assertNativeSecureStorage() {
  if (Platform.OS === 'web') {
    throw new Error('Secure key storage is available in the Android app, not in the web preview.');
  }
}

export type { MapProvider, RouteAlternative } from './types';
