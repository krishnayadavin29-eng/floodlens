import type { Coordinates, PlaceSearchResult, TravelMode } from '@/src/types/domain';

export interface RouteAlternative {
  id: string;
  coordinates: Coordinates[];
  distanceMeters: number;
  durationSeconds: number;
  source: string;
}

export interface MapProvider {
  readonly name: string;
  searchPlaces(query: string): Promise<PlaceSearchResult[]>;
  geocode(address: string): Promise<PlaceSearchResult | null>;
  reverseGeocode(point: Coordinates): Promise<PlaceSearchResult | null>;
  getRoutes(
    origin: Coordinates,
    destination: Coordinates,
    mode: TravelMode,
    waypoints?: Coordinates[],
  ): Promise<RouteAlternative[]>;
}
