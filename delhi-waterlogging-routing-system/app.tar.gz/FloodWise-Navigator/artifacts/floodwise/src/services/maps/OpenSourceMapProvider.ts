import { SEARCH_CACHE_MS } from '@/src/config/constants';
import type { Coordinates, PlaceSearchResult, TravelMode } from '@/src/types/domain';
import type { MapProvider, RouteAlternative } from './types';

const searchCache = new Map<string, { expiresAt: number; value: PlaceSearchResult[] }>();
const routeCache = new Map<string, RouteAlternative[]>();
const NOMINATIM_HEADERS = {
  Accept: 'application/json',
  'Accept-Language': 'en',
  'User-Agent': 'FloodWise/1.0 (waterlogging safety app)',
};

type NominatimPlace = {
  place_id: number;
  display_name: string;
  name?: string;
  lat: string;
  lon: string;
};

type OsrmResponse = {
  code: string;
  routes?: {
    distance: number;
    duration: number;
    geometry: { coordinates: [number, number][] };
  }[];
};

function mapPlace(place: NominatimPlace): PlaceSearchResult {
  const parts = place.display_name.split(',');
  return {
    name: place.name || parts[0]?.trim() || 'Selected place',
    address: place.display_name,
    latitude: Number(place.lat),
    longitude: Number(place.lon),
  };
}

export class OpenSourceMapProvider implements MapProvider {
  readonly name = 'OpenStreetMap';

  async searchPlaces(query: string) {
    const normalized = query.trim().toLowerCase();
    if (normalized.length < 3) return [];
    const cached = searchCache.get(normalized);
    if (cached && cached.expiresAt > Date.now()) return cached.value;
    const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=6&q=${encodeURIComponent(query)}`;
    const response = await fetch(url, {
      headers: NOMINATIM_HEADERS,
      signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw new Error(`Place search returned ${response.status}.`);
    const places = ((await response.json()) as NominatimPlace[]).map(mapPlace);
    searchCache.set(normalized, { expiresAt: Date.now() + SEARCH_CACHE_MS, value: places });
    return places;
  }

  async geocode(address: string) {
    return (await this.searchPlaces(address))[0] ?? null;
  }

  async reverseGeocode(point: Coordinates) {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${point.latitude}&lon=${point.longitude}`,
      { headers: NOMINATIM_HEADERS, signal: AbortSignal.timeout(8000) },
    );
    if (!response.ok) throw new Error(`Place lookup returned ${response.status}.`);
    const place = (await response.json()) as NominatimPlace;
    return mapPlace(place);
  }

  async getRoutes(
    origin: Coordinates,
    destination: Coordinates,
    mode: TravelMode,
    waypoints: Coordinates[] = [],
  ) {
    const points = [origin, ...waypoints, destination];
    const key = `${mode}:${points.map((point) => `${point.latitude.toFixed(4)},${point.longitude.toFixed(4)}`).join('|')}`;
    const cached = routeCache.get(key);
    if (cached) return cached;
    const coordinates = points.map((point) => `${point.longitude},${point.latitude}`).join(';');
    const url = `https://router.project-osrm.org/route/v1/driving/${coordinates}?overview=full&geometries=geojson&alternatives=true&steps=false`;
    const response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw new Error(`Route service returned ${response.status}.`);
    const data = (await response.json()) as OsrmResponse;
    if (data.code !== 'Ok' || !data.routes?.length) {
      throw new Error('No route was found between those places.');
    }
    const routes = data.routes.slice(0, 3).map((route, index) => ({
      id: `osm-${index}-${Math.round(route.distance)}`,
      coordinates: route.geometry.coordinates.map(([longitude, latitude]) => ({
        latitude,
        longitude,
      })),
      distanceMeters: route.distance,
      durationSeconds:
        mode === 'walking'
          ? route.distance / 1.25
          : mode === 'cycling'
            ? route.distance / 7
            : route.duration,
      source: `${this.name} / OSRM`,
    }));
    routeCache.set(key, routes);
    return routes;
  }
}
