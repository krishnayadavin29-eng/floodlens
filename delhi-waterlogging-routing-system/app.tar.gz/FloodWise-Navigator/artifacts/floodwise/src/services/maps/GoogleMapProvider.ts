import type { Coordinates, PlaceSearchResult, TravelMode } from '@/src/types/domain';
import type { MapProvider, RouteAlternative } from './types';

type GooglePlace = {
  place_id: string;
  description?: string;
  name?: string;
  formatted_address?: string;
  geometry?: { location: { lat: number; lng: number } };
};

function decodePolyline(encoded: string): Coordinates[] {
  const points: Coordinates[] = [];
  let index = 0;
  let latitude = 0;
  let longitude = 0;
  while (index < encoded.length) {
    let result = 0;
    let shift = 0;
    let byte: number;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    latitude += result & 1 ? ~(result >> 1) : result >> 1;
    result = 0;
    shift = 0;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    longitude += result & 1 ? ~(result >> 1) : result >> 1;
    points.push({ latitude: latitude / 1e5, longitude: longitude / 1e5 });
  }
  return points;
}

export class GoogleMapProvider implements MapProvider {
  readonly name = 'Google Maps';
  constructor(private readonly apiKey: string) {}

  async searchPlaces(query: string) {
    if (query.trim().length < 3) return [];
    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(query)}&key=${encodeURIComponent(this.apiKey)}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error(`Google place search returned ${response.status}.`);
    const data = (await response.json()) as { predictions?: GooglePlace[]; status?: string };
    if (data.status && data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
      throw new Error(`Google Places: ${data.status}. Check the APIs enabled for this key.`);
    }
    const details = await Promise.all(
      (data.predictions ?? []).slice(0, 5).map(async (place) => {
        const detailResponse = await fetch(
          `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(place.place_id)}&fields=name,formatted_address,geometry&key=${encodeURIComponent(this.apiKey)}`,
          { signal: AbortSignal.timeout(8000) },
        );
        if (!detailResponse.ok) return null;
        const detailData = (await detailResponse.json()) as { result?: GooglePlace };
        const result = detailData.result;
        const location = result?.geometry?.location;
        if (!location) return null;
        return {
          name: result.name || place.description || 'Selected place',
          address: result.formatted_address || place.description || '',
          latitude: location.lat,
          longitude: location.lng,
        };
      }),
    );
    return details.filter((place): place is PlaceSearchResult => place !== null);
  }

  async geocode(address: string) {
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${encodeURIComponent(this.apiKey)}`,
      { signal: AbortSignal.timeout(8000) },
    );
    if (!response.ok) throw new Error(`Google Geocoding returned ${response.status}.`);
    const data = (await response.json()) as { results?: GooglePlace[]; status?: string };
    const result = data.results?.[0];
    const location = result?.geometry?.location;
    if (!location) return null;
    return {
      name: result.name || result.formatted_address || address,
      address: result.formatted_address || address,
      latitude: location.lat,
      longitude: location.lng,
    };
  }

  async reverseGeocode(point: Coordinates) {
    return this.geocode(`${point.latitude},${point.longitude}`);
  }

  async getRoutes(
    origin: Coordinates,
    destination: Coordinates,
    mode: TravelMode,
    waypoints: Coordinates[] = [],
  ) {
    const toLatLng = (point: Coordinates) => `${point.latitude},${point.longitude}`;
    const modeValue = mode === 'walking' ? 'walking' : mode === 'cycling' ? 'bicycling' : 'driving';
    const waypointText = waypoints.length
      ? `&waypoints=${waypoints.map(toLatLng).join('|')}`
      : '';
    const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${toLatLng(origin)}&destination=${toLatLng(destination)}&mode=${modeValue}&alternatives=true${waypointText}&key=${encodeURIComponent(this.apiKey)}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw new Error(`Google Directions returned ${response.status}.`);
    const data = (await response.json()) as {
      status?: string;
      routes?: {
        overview_polyline?: { points: string };
        legs?: { distance?: { value: number }; duration?: { value: number } }[];
      }[];
    };
    if (data.status !== 'OK' || !data.routes?.length) {
      throw new Error(`Google Directions: ${data.status ?? 'no routes found'}.`);
    }
    return data.routes.slice(0, 3).map((route, index) => ({
      id: `google-${index}`,
      coordinates: decodePolyline(route.overview_polyline?.points ?? ''),
      distanceMeters: route.legs?.reduce((sum, leg) => sum + (leg.distance?.value ?? 0), 0) ?? 0,
      durationSeconds: route.legs?.reduce((sum, leg) => sum + (leg.duration?.value ?? 0), 0) ?? 0,
      source: this.name,
    })) as RouteAlternative[];
  }
}
