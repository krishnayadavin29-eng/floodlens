import { riskLevelForProbability } from '@/src/config/constants';
import { getPredictionApiKey } from '@/src/services/maps';
import type { PredictionInput, PredictionResult } from './types';
import { BasePredictionService } from './PredictionService';

export class RemotePredictionService extends BasePredictionService {
  constructor(private readonly baseUrl: string) {
    super();
  }

  async predictPoint(input: PredictionInput): Promise<PredictionResult> {
    if (!this.baseUrl.trim()) {
      throw new Error('Add your model API URL in Settings before choosing Remote mode.');
    }
    const apiKey = await getPredictionApiKey();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12_000);
    try {
      const response = await fetch(`${this.baseUrl.replace(/\/$/, '')}/predict`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
        },
        body: JSON.stringify(input),
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`Prediction API returned ${response.status}.`);
      const raw = (await response.json()) as Partial<PredictionResult> & { probability?: number };
      if (typeof raw.probability !== 'number') {
        throw new Error('Prediction API response is missing a probability.');
      }
      const probability = Math.max(0, Math.min(1, raw.probability));
      return {
        probability,
        risk_level: raw.risk_level ?? riskLevelForProbability(probability),
        confidence: raw.confidence ?? 0.7,
        factors: raw.factors ?? [],
        forecast: raw.forecast,
        model_version: raw.model_version ?? 'remote model',
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  async predictBatch(inputs: PredictionInput[]) {
    if (!this.baseUrl.trim()) {
      throw new Error('Add your model API URL in Settings before choosing Remote mode.');
    }
    const apiKey = await getPredictionApiKey();
    const response = await fetch(`${this.baseUrl.replace(/\/$/, '')}/predict/batch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
      },
      body: JSON.stringify({ points: inputs }),
      signal: AbortSignal.timeout(15_000),
    });
    if (!response.ok) throw new Error(`Batch prediction API returned ${response.status}.`);
    const data = (await response.json()) as { results?: PredictionResult[] };
    if (!Array.isArray(data.results) || data.results.length !== inputs.length) {
      throw new Error('Batch prediction response must contain one result per input point.');
    }
    return data.results.map((result) => ({
      ...result,
      probability: Math.max(0, Math.min(1, result.probability)),
      risk_level: result.risk_level ?? riskLevelForProbability(result.probability),
    }));
  }
}
