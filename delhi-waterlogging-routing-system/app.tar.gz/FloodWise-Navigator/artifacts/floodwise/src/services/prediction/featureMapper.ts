import drainageData from '@/src/data/drainage.json';
import type { Coordinates } from '@/src/types/domain';
import type { PredictionInput } from './types';
import { WEATHER_CACHE_MS } from '@/src/config/constants';

type WeatherRecord = {
  hourly?: {
    time?: string[];
    precipitation?: number[];
    precipitation_probability?: number[];
  };
};

type ElevationRecord = { elevation?: number[] };
type Overrides = {
  rainfallIntensity?: number;
  rainfallDuration?: number;
  rainfallTotal?: number;
};

const weatherCache = new Map<string, { expiresAt: number; value: WeatherRecord }>();
const elevationCache = new Map<string, number>();
const MAX_RETRIES = 3;

function cacheKey(point: Coordinates) {
  return `${point.latitude.toFixed(3)},${point.longitude.toFixed(3)}`;
}

async function getJsonWithRetry<T>(url: string): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt < MAX_RETRIES; attempt += 1) {
    try {
      const response = await fetch(url, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(9000),
      });
      if (!response.ok) throw new Error(`Data service returned ${response.status}`);
      return (await response.json()) as T;
    } catch (error) {
      lastError = error;
      if (attempt < MAX_RETRIES - 1) {
        await new Promise((resolve) => setTimeout(resolve, 350 * 2 ** attempt));
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Weather data unavailable');
}

async function loadElevation(points: Coordinates[]): Promise<number[]> {
  const output = new Array<number>(points.length);
  const missing: { point: Coordinates; index: number }[] = [];
  points.forEach((point, index) => {
    const cached = elevationCache.get(cacheKey(point));
    if (cached !== undefined) output[index] = cached;
    else missing.push({ point, index });
  });

  for (let offset = 0; offset < missing.length; offset += 25) {
    const chunk = missing.slice(offset, offset + 25);
    const latitude = chunk.map(({ point }) => point.latitude).join(',');
    const longitude = chunk.map(({ point }) => point.longitude).join(',');
    try {
      const data = await getJsonWithRetry<ElevationRecord>(
        `https://api.open-meteo.com/v1/elevation?latitude=${latitude}&longitude=${longitude}`,
      );
      chunk.forEach(({ point, index }, chunkIndex) => {
        const value = data.elevation?.[chunkIndex] ?? 8;
        elevationCache.set(cacheKey(point), value);
        output[index] = value;
      });
    } catch {
      chunk.forEach(({ index }) => {
        output[index] = 8;
      });
    }
  }
  return output;
}

async function loadWeather(points: Coordinates[]): Promise<WeatherRecord[]> {
  const now = Date.now();
  const output = new Array<WeatherRecord>(points.length);
  const missing: { point: Coordinates; index: number }[] = [];
  points.forEach((point, index) => {
    const cached = weatherCache.get(cacheKey(point));
    if (cached && cached.expiresAt > now) output[index] = cached.value;
    else missing.push({ point, index });
  });

  for (let offset = 0; offset < missing.length; offset += 20) {
    const chunk = missing.slice(offset, offset + 20);
    const latitude = chunk.map(({ point }) => point.latitude).join(',');
    const longitude = chunk.map(({ point }) => point.longitude).join(',');
    try {
      const data = await getJsonWithRetry<WeatherRecord | WeatherRecord[]>(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&hourly=precipitation,precipitation_probability&forecast_days=1&timezone=auto`,
      );
      const records = Array.isArray(data) ? data : [data];
      chunk.forEach(({ point, index }, chunkIndex) => {
        const value = records[chunkIndex] ?? records[0] ?? {};
        weatherCache.set(cacheKey(point), { expiresAt: now + WEATHER_CACHE_MS, value });
        output[index] = value;
      });
    } catch {
      chunk.forEach(({ index }) => {
        output[index] = {};
      });
    }
  }
  return output;
}

function drainageFor(point: Coordinates) {
  const zone = drainageData.zones.find(({ bounds }) =>
    point.latitude >= bounds.south &&
    point.latitude <= bounds.north &&
    point.longitude >= bounds.west &&
    point.longitude <= bounds.east,
  );
  return zone ?? drainageData.default;
}

function mapOne(
  point: Coordinates,
  elevation: number,
  weather: WeatherRecord,
  overrides: Overrides,
  weatherEnabled: boolean,
): PredictionInput {
  const hourly = weather.hourly;
  const precipitation = hourly?.precipitation ?? [];
  const firstWetIndex = precipitation.findIndex((value) => value >= 0.1);
  const rainfallDuration = firstWetIndex < 0
    ? 0
    : Math.max(
        1,
        precipitation
          .slice(firstWetIndex)
          .findIndex((value) => value < 0.1) < 0
          ? precipitation.length - firstWetIndex
          : precipitation
              .slice(firstWetIndex)
              .findIndex((value) => value < 0.1),
      );
  const rain = weatherEnabled ? precipitation[0] ?? 1.5 : 1.5;
  const drainage = drainageFor(point);
  return {
    latitude: point.latitude,
    longitude: point.longitude,
    timestamp: new Date().toISOString(),
    elevation,
    rainfall_intensity: overrides.rainfallIntensity ?? rain,
    rainfall_duration: overrides.rainfallDuration ?? (weatherEnabled ? rainfallDuration : 2),
    rainfall_total:
      overrides.rainfallTotal ??
      (weatherEnabled
        ? precipitation.slice(0, 6).reduce((sum, value) => sum + value, 0)
        : 4),
    drainage_quality: drainage.quality as PredictionInput['drainage_quality'],
    extra_features: {
      drainage_zone: 'name' in drainage ? drainage.name : 'local default',
      rainfall_probability: hourly?.precipitation_probability?.[0] ?? null,
      feature_source: weatherEnabled ? 'Open-Meteo' : 'manual/demo',
    },
  };
}

/**
 * The only place where app data is gathered and translated into model inputs.
 * Add/remove/rename a feature here and in PredictionInput. To map a new source,
 * fetch it in loadElevation/loadWeather (or a sibling loader) and add it below.
 */
export async function mapPredictionFeatures(
  point: Coordinates,
  options: { weatherEnabled?: boolean; overrides?: Overrides; networkAvailable?: boolean } = {},
): Promise<PredictionInput> {
  const [input] = await mapPredictionFeaturesBatch([point], options);
  return input;
}

export async function mapPredictionFeaturesBatch(
  points: Coordinates[],
  options: { weatherEnabled?: boolean; overrides?: Overrides; networkAvailable?: boolean } = {},
): Promise<PredictionInput[]> {
  if (points.length === 0) return [];
  const weatherEnabled = options.weatherEnabled ?? true;
  const networkAvailable = options.networkAvailable ?? true;
  const [elevations, weather] = await Promise.all([
    networkAvailable
      ? loadElevation(points)
      : Promise.resolve(points.map(() => 8)),
    weatherEnabled && networkAvailable
      ? loadWeather(points)
      : Promise.resolve(points.map(() => ({} as WeatherRecord))),
  ]);
  return points.map((point, index) =>
    mapOne(point, elevations[index] ?? 8, weather[index] ?? {}, options.overrides ?? {}, weatherEnabled),
  );
}
