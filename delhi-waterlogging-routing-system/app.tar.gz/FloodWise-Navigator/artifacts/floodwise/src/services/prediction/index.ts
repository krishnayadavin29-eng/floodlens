import type { AppSettings } from '@/src/types/domain';
import type { PredictionService } from './types';
import { MockPredictionService } from './MockPredictionService';
import { OnDevicePredictionService } from './OnDevicePredictionService';
import { RemotePredictionService } from './RemotePredictionService';

export function getPredictionService(settings: AppSettings): PredictionService {
  if (settings.predictionMode === 'remote') {
    return new RemotePredictionService(settings.predictionApiUrl);
  }
  if (settings.predictionMode === 'ondevice') {
    return new OnDevicePredictionService();
  }
  return new MockPredictionService();
}

export type { PredictionInput, PredictionResult, PredictionService } from './types';
