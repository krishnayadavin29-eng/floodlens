import type { PredictionInput, PredictionResult } from './types';
import { BasePredictionService } from './PredictionService';

export class OnDevicePredictionService extends BasePredictionService {
  async predictPoint(_input: PredictionInput): Promise<PredictionResult> {
    throw new Error(
      'On-device prediction is not configured yet. Add your TFLite or ONNX runtime and model in this service.',
    );
  }
}
