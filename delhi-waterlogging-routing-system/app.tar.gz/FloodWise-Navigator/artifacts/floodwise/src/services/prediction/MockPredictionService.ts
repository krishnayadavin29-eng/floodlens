import { riskLevelForProbability } from '@/src/config/constants';
import type { PredictionInput, PredictionResult } from './types';
import { BasePredictionService } from './PredictionService';

function stableNoise(latitude: number, longitude: number) {
  const value = Math.abs(Math.sin(latitude * 73.31 + longitude * 91.7) * 43758.5453);
  return (value - Math.floor(value)) * 0.1 - 0.05;
}

export class MockPredictionService extends BasePredictionService {
  async predictPoint(input: PredictionInput): Promise<PredictionResult> {
    await new Promise((resolve) => setTimeout(resolve, 120));
    const rainScore = Math.min(input.rainfall_intensity / 18, 1) * 0.38;
    const durationScore = Math.min(input.rainfall_duration / 8, 1) * 0.18;
    const elevationScore = (1 - Math.min(Math.max(input.elevation, 0) / 35, 1)) * 0.16;
    const drainageScore =
      (1 - (input.drainage_quality === 'good' ? 0.82 : input.drainage_quality === 'average' ? 0.5 : 0.2)) *
      0.24;
    const probability = Math.max(
      0.04,
      Math.min(
        0.97,
        0.04 +
          rainScore +
          durationScore +
          elevationScore +
          drainageScore +
          stableNoise(input.latitude, input.longitude),
      ),
    );
    const hourlyRain = input.rainfall_intensity;
    const forecast = [0, 1, 3, 6].map((hours) => ({
      time: hours === 0 ? 'Now' : `+${hours}h`,
      probability: Math.max(
        0.02,
        Math.min(
          0.97,
          probability * (hours === 0 ? 1 : Math.max(0.55, 1 - hours * 0.055)) +
            Math.min(hourlyRain / 80, 0.08),
        ),
      ),
    }));
    return {
      probability,
      risk_level: riskLevelForProbability(probability),
      confidence: 0.82,
      factors: [
        { name: 'Rain intensity', impact: rainScore },
        { name: 'Rain duration', impact: durationScore },
        { name: 'Low elevation', impact: elevationScore },
        { name: 'Drainage quality', impact: drainageScore },
      ].sort((a, b) => b.impact - a.impact),
      forecast,
      model_version: 'FloodWise demo model 0.1',
    };
  }
}
