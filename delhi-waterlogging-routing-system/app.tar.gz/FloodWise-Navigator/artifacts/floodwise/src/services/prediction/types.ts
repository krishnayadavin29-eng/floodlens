import type { Coordinates, RiskLevel } from '@/src/types/domain';

export interface PredictionInput extends Coordinates {
  timestamp: string;
  elevation: number;
  rainfall_intensity: number;
  rainfall_duration: number;
  rainfall_total?: number;
  drainage_quality: 'poor' | 'average' | 'good';
  extra_features: Record<string, unknown>;
}

export interface PredictionFactor {
  name: string;
  impact: number;
}

export interface PredictionResult {
  probability: number;
  risk_level: RiskLevel;
  confidence: number;
  factors: PredictionFactor[];
  forecast?: { time: string; probability: number }[];
  model_version: string;
}

export interface PredictionService {
  predictPoint(input: PredictionInput): Promise<PredictionResult>;
  predictBatch(inputs: PredictionInput[]): Promise<PredictionResult[]>;
  predictRoute(inputs: PredictionInput[]): Promise<PredictionResult[]>;
}
