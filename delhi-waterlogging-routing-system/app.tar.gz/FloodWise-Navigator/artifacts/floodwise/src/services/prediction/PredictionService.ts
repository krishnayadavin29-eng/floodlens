import type { PredictionInput, PredictionService } from './types';

export abstract class BasePredictionService implements PredictionService {
  abstract predictPoint(input: PredictionInput): Promise<ReturnTypePromise>;

  async predictBatch(inputs: PredictionInput[]) {
    return Promise.all(inputs.map((input) => this.predictPoint(input)));
  }

  async predictRoute(inputs: PredictionInput[]) {
    return this.predictBatch(inputs);
  }
}

type ReturnTypePromise = import('./types').PredictionResult;
