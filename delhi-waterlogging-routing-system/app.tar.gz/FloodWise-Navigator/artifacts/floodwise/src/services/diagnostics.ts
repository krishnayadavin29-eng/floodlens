export interface DiagnosticContext {
  area: 'app-render' | 'map-search' | 'place-risk' | 'route-planning' | 'settings';
}

export type ErrorReporter = (
  error: Error,
  context: DiagnosticContext,
) => void;

let reporter: ErrorReporter | undefined;

/**
 * Register an optional reporting adapter (for example, a Sentry adapter).
 * The default is intentionally disabled so no diagnostics leave the device.
 */
export function registerErrorReporter(next?: ErrorReporter) {
  reporter = next;
}

export function captureAppError(error: unknown, context: DiagnosticContext) {
  if (!reporter) return;
  reporter(
    error instanceof Error ? error : new Error(String(error)),
    context,
  );
}
