import { useColors } from '@/hooks/useColors';
import colors from '@/constants/colors';
import { useFloodStore } from '@/src/store/appStore';

export function useAppColors() {
  const systemColors = useColors();
  const theme = useFloodStore((state) => state.settings.theme);
  if (theme === 'light') return { ...colors.light, radius: colors.radius };
  if (theme === 'dark') return { ...colors.dark, radius: colors.radius };
  return systemColors;
}
