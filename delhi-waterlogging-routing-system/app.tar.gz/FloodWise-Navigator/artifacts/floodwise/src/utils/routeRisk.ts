import { MAX_ROUTE_SAMPLES, ROUTE_RECOMMENDATION_EXTRA_TIME, ROUTE_SAMPLE_METERS } from '@/src/config/constants';
import type { Coordinates } from '@/src/types/domain';
import type { PredictionResult } from '@/src/services/prediction/types';
import type { RouteAlternative } from '@/src/services/maps/types';

export interface AnalyzedRoute extends RouteAlternative {
  results: PredictionResult[];
  maxRisk: number;
  averageRisk: number;
  highRiskSpots: number;
  routeScore: number;
  recommended: boolean;
  fastest: boolean;
}

function distanceMeters(a: Coordinates, b: Coordinates) {
  const radians = (value: number) => (value * Math.PI) / 180;
  const dLat = radians(b.latitude - a.latitude);
  const dLon = radians(b.longitude - a.longitude);
  const value =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(radians(a.latitude)) *
      Math.cos(radians(b.latitude)) *
      Math.sin(dLon / 2) ** 2;
  return 6_371_000 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

export function sampleRoutePoints(
  coordinates: Coordinates[],
  everyMeters = ROUTE_SAMPLE_METERS,
  maximum = MAX_ROUTE_SAMPLES,
): Coordinates[] {
  if (coordinates.length <= 2) return coordinates;
  const samples: Coordinates[] = [coordinates[0]!];
  let accumulated = 0;
  for (let index = 1; index < coordinates.length; index += 1) {
    accumulated += distanceMeters(coordinates[index - 1]!, coordinates[index]!);
    if (accumulated >= everyMeters) {
      samples.push(coordinates[index]!);
      accumulated = 0;
    }
  }
  const last = coordinates[coordinates.length - 1]!;
  const previous = samples[samples.length - 1]!;
  if (distanceMeters(previous, last) > 20) samples.push(last);
  if (samples.length <= maximum) return samples;
  return Array.from({ length: maximum }, (_, index) =>
    samples[Math.round((index * (samples.length - 1)) / (maximum - 1))]!,
  );
}

export function analyzeRoutes(
  routes: RouteAlternative[],
  predictions: PredictionResult[][],
  extraTimeRatio = ROUTE_RECOMMENDATION_EXTRA_TIME,
): AnalyzedRoute[] {
  const candidates = routes.map((route, index) => {
    const results = predictions[index] ?? [];
    const risks = results.map((result) => result.probability);
    const maxRisk = risks.length ? Math.max(...risks) : 0;
    const averageRisk = risks.length
      ? risks.reduce((sum, risk) => sum + risk, 0) / risks.length
      : 0;
    const highRiskSpots = risks.filter((risk) => risk >= 0.5).length;
    return {
      ...route,
      results,
      maxRisk,
      averageRisk,
      highRiskSpots,
      routeScore: averageRisk * 0.72 + maxRisk * 0.28,
      recommended: false,
      fastest: false,
    };
  });
  if (!candidates.length) return [];
  const fastest = candidates.reduce((best, route) =>
    route.durationSeconds < best.durationSeconds ? route : best,
  );
  const eligible = candidates.filter(
    (route) => route.durationSeconds <= fastest.durationSeconds * (1 + extraTimeRatio),
  );
  const recommended = eligible.reduce((best, route) =>
    route.routeScore < best.routeScore ? route : best,
  );
  return candidates.map((route) => ({
    ...route,
    fastest: route.id === fastest.id,
    recommended: route.id === recommended.id,
  }));
}

export function recommendationMessage(route: AnalyzedRoute, fastest: AnalyzedRoute) {
  if (route.id === fastest.id) return 'Lowest exposure and the quickest option.';
  const extraMinutes = Math.max(
    1,
    Math.round((route.durationSeconds - fastest.durationSeconds) / 60),
  );
  return `Avoids ${route.highRiskSpots} high-risk spots, adds about ${extraMinutes} min.`;
}
