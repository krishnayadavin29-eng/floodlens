import { describe, expect, it } from 'vitest';
import type { PredictionResult } from '@/src/services/prediction/types';
import type { RouteAlternative } from '@/src/services/maps/types';
import { analyzeRoutes, sampleRoutePoints } from './routeRisk';

const result = (probability: number): PredictionResult => ({
  probability,
  risk_level: probability >= 0.75 ? 'high' : probability >= 0.5 ? 'moderate' : 'low',
  confidence: 0.8,
  factors: [],
  model_version: 'test',
});

const route = (id: string, durationSeconds: number): RouteAlternative => ({
  id,
  coordinates: [
    { latitude: 22.55, longitude: 88.34 },
    { latitude: 22.56, longitude: 88.35 },
  ],
  distanceMeters: durationSeconds,
  durationSeconds,
  source: 'test',
});

describe('route risk analysis', () => {
  it('samples long routes to the configured maximum and preserves endpoints', () => {
    const coordinates = Array.from({ length: 250 }, (_, index) => ({
      latitude: 22.5 + index * 0.002,
      longitude: 88.3 + index * 0.001,
    }));

    const sampled = sampleRoutePoints(coordinates, 40, 24);

    expect(sampled).toHaveLength(24);
    expect(sampled[0]).toEqual(coordinates[0]);
    expect(sampled.at(-1)).toEqual(coordinates.at(-1));
  });

  it('aggregates maximum and average exposure for each route', () => {
    const [analyzed] = analyzeRoutes(
      [route('one', 600)],
      [[result(0.1), result(0.8)]],
    );

    expect(analyzed?.maxRisk).toBe(0.8);
    expect(analyzed?.averageRisk).toBeCloseTo(0.45);
    expect(analyzed?.highRiskSpots).toBe(1);
  });

  it('recommends the lowest-risk route within the 25% time window', () => {
    const analyzed = analyzeRoutes(
      [route('fastest', 1000), route('safer', 1200), route('too-slow', 1300)],
      [[result(0.65)], [result(0.2)], [result(0.05)]],
    );

    expect(analyzed.find((item) => item.fastest)?.id).toBe('fastest');
    expect(analyzed.find((item) => item.recommended)?.id).toBe('safer');
    expect(analyzed.find((item) => item.id === 'too-slow')?.recommended).toBe(false);
  });
});
