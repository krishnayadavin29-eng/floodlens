/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#102a35',
    tint: '#0ea5e9',

    // Core surfaces
    background: '#f3f8fa',
    foreground: '#102a35',

    // Cards / elevated surfaces
    card: '#ffffff',
    cardForeground: '#102a35',

    // Primary action color (buttons, links, active states)
    primary: '#0ea5e9',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e6f3f7',
    secondaryForeground: '#164e63',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#eaf1f4',
    mutedForeground: '#67808b',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#d5f3ef',
    accentForeground: '#036b66',

    // Destructive actions (delete, error states)
    destructive: '#dc4c4c',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#dce8ec',
    input: '#dce8ec',
  },
  dark: {
    text: '#e8f3f6',
    tint: '#38bdf8',
    background: '#071b25',
    foreground: '#e8f3f6',
    card: '#0d2935',
    cardForeground: '#e8f3f6',
    primary: '#38bdf8',
    primaryForeground: '#06202b',
    secondary: '#163947',
    secondaryForeground: '#b7e4f2',
    muted: '#16313d',
    mutedForeground: '#91aeb8',
    accent: '#123c3c',
    accentForeground: '#7ee7d1',
    destructive: '#f06a6a',
    destructiveForeground: '#ffffff',
    border: '#21414d',
    input: '#21414d',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 20,
};

export default colors;
